import base64
import os

with open("public/sounds/intro-uefa.mp3", "rb") as f:
    uefa_b64 = base64.b64encode(f.read()).decode("utf-8")

with open("public/sounds/pegue-seu-banquinho.mp3", "rb") as f:
    banquinho_b64 = base64.b64encode(f.read()).decode("utf-8")

template_head = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xadrez 3D Master - Arena Azul</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- FontAwesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Confetti -->
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
    <style>
        body {
            margin: 0;
            overflow: hidden;
            background-color: #030712;
            font-family: 'Outfit', sans-serif;
            user-select: none;
            -webkit-user-select: none;
        }
        canvas {
            display: block;
            width: 100vw;
            height: 100vh;
        }
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: rgba(10, 22, 45, 0.6);
        }
        ::-webkit-scrollbar-thumb {
            background: rgba(59, 130, 246, 0.4);
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: rgba(59, 130, 246, 0.8);
        }
    </style>
</head>
<body class="text-slate-100 bg-[#030712]">

    <!-- Welcome & Mode Selection Modal -->
    <div id="welcome-screen" class="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
        <div class="relative bg-gradient-to-b from-[#091738] via-[#07132e] to-[#04091a] border border-blue-600/40 rounded-3xl p-6 md:p-8 max-w-2xl w-full shadow-2xl shadow-blue-950/80 flex flex-col gap-6 overflow-hidden">
            <div class="text-center space-y-2">
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-700 to-cyan-500 text-white shadow-xl shadow-blue-600/30 mb-1 border border-cyan-300/30">
                    <span class="text-3xl font-serif">♔</span>
                </div>
                <h1 class="text-2xl md:text-3xl font-extrabold tracking-tight text-white">Xadrez 3D Master</h1>
                <p class="text-blue-200/80 text-xs md:text-sm">Arena de xadrez em tons de azul escuro com bots, multiplayer e trilhas especiais</p>
            </div>

            <!-- Mode Selection Cards -->
            <div id="main-modes-grid" class="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                <button onclick="showBotSelection()" class="group bg-[#0c1f47]/80 hover:bg-[#122e6b] border border-blue-800/60 hover:border-cyan-400 p-4 rounded-2xl text-left transition-all flex flex-col justify-between shadow-lg hover:shadow-cyan-500/10 cursor-pointer">
                    <div class="w-10 h-10 rounded-xl bg-blue-600/30 text-cyan-300 flex items-center justify-center text-lg mb-3 border border-blue-500/30">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-sm text-slate-100 flex items-center justify-between">
                            <span>Jogar vs Bot / IA</span>
                            <i class="fa-solid fa-chevron-right text-xs text-cyan-400"></i>
                        </h3>
                        <p class="text-[11px] text-blue-200/70 mt-1">5 bots únicos: do Pipoca ao Grão-Mestre Zenith.</p>
                    </div>
                </button>

                <button onclick="showOnlineSetup()" class="group bg-[#0c1f47]/80 hover:bg-[#122e6b] border border-blue-800/60 hover:border-cyan-400 p-4 rounded-2xl text-left transition-all flex flex-col justify-between shadow-lg hover:shadow-cyan-500/10 cursor-pointer">
                    <div class="w-10 h-10 rounded-xl bg-indigo-600/30 text-indigo-300 flex items-center justify-center text-lg mb-3 border border-indigo-500/30">
                        <i class="fa-solid fa-globe"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-sm text-slate-100 flex items-center justify-between">
                            <span>Amigo de Longe</span>
                            <i class="fa-solid fa-chevron-right text-xs text-cyan-400"></i>
                        </h3>
                        <p class="text-[11px] text-blue-200/70 mt-1">Crie ou entre numa sala com código compartilhado.</p>
                    </div>
                </button>

                <button onclick="startLocalGame()" class="group bg-[#0c1f47]/80 hover:bg-[#122e6b] border border-blue-800/60 hover:border-cyan-400 p-4 rounded-2xl text-left transition-all flex flex-col justify-between shadow-lg hover:shadow-cyan-500/10 cursor-pointer">
                    <div class="w-10 h-10 rounded-xl bg-emerald-600/30 text-emerald-300 flex items-center justify-center text-lg mb-3 border border-emerald-500/30">
                        <i class="fa-solid fa-user-group"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-sm text-slate-100 flex items-center justify-between">
                            <span>2 Jogadores Local</span>
                            <i class="fa-solid fa-chevron-right text-xs text-cyan-400"></i>
                        </h3>
                        <p class="text-[11px] text-blue-200/70 mt-1">Jogue com um amigo na mesma tela.</p>
                    </div>
                </button>
            </div>

            <!-- Bot Submenu -->
            <div id="bot-selection" class="hidden flex-col gap-4 border-t border-blue-900/50 pt-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-bold text-sm text-white">Escolha a Dificuldade da IA:</h3>
                    <button onclick="hideSubmenus()" class="text-xs text-cyan-300 hover:text-white cursor-pointer"><i class="fa-solid fa-arrow-left"></i> Voltar</button>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-5 gap-2">
                    <button onclick="selectBot(1)" class="p-3 bg-[#0c1f47] hover:bg-blue-600/30 border border-blue-800 hover:border-cyan-400 rounded-2xl text-center cursor-pointer transition-all">
                        <div class="text-xl mb-1">🍿</div>
                        <div class="text-[10px] font-bold text-cyan-300">Nível 1</div>
                        <div class="font-bold text-xs text-white">Pipoca</div>
                        <div class="text-[10px] text-slate-400">Iniciante</div>
                    </button>
                    <button onclick="selectBot(2)" class="p-3 bg-[#0c1f47] hover:bg-blue-600/30 border border-blue-800 hover:border-cyan-400 rounded-2xl text-center cursor-pointer transition-all">
                        <div class="text-xl mb-1">⚡</div>
                        <div class="text-[10px] font-bold text-cyan-300">Nível 2</div>
                        <div class="font-bold text-xs text-white">Sr. Faísca</div>
                        <div class="text-[10px] text-slate-400">Intermediário</div>
                    </button>
                    <button onclick="selectBot(3)" class="p-3 bg-[#0c1f47] hover:bg-blue-600/30 border border-blue-800 hover:border-cyan-400 rounded-2xl text-center cursor-pointer transition-all">
                        <div class="text-xl mb-1">🔮</div>
                        <div class="text-[10px] font-bold text-cyan-300">Nível 3</div>
                        <div class="font-bold text-xs text-white">Mestra Sophia</div>
                        <div class="text-[10px] text-slate-400">Avançado</div>
                    </button>
                    <button onclick="selectBot(4)" class="p-3 bg-[#0c1f47] hover:bg-blue-600/30 border border-blue-800 hover:border-cyan-400 rounded-2xl text-center cursor-pointer transition-all">
                        <div class="text-xl mb-1">🤖</div>
                        <div class="text-[10px] font-bold text-cyan-300">Nível 4</div>
                        <div class="font-bold text-xs text-white">Tytan 9000</div>
                        <div class="text-[10px] text-slate-400">Expert</div>
                    </button>
                    <button onclick="selectBot(5)" class="p-3 bg-[#0c1f47] hover:bg-blue-600/30 border border-blue-800 hover:border-cyan-400 rounded-2xl text-center cursor-pointer transition-all">
                        <div class="text-xl mb-1">👑</div>
                        <div class="text-[10px] font-bold text-amber-300">Nível 5</div>
                        <div class="font-bold text-xs text-white">Zenith</div>
                        <div class="text-[10px] text-slate-400">Lendário</div>
                    </button>
                </div>
            </div>

            <!-- Online Submenu -->
            <div id="online-selection" class="hidden flex-col gap-4 border-t border-blue-900/50 pt-4">
                <div class="flex items-center justify-between">
                    <h3 class="font-bold text-sm text-white">Sala Online com Amigo</h3>
                    <button onclick="hideSubmenus()" class="text-xs text-cyan-300 hover:text-white cursor-pointer"><i class="fa-solid fa-arrow-left"></i> Voltar</button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="bg-[#081533]/90 border border-blue-800/60 p-4 rounded-2xl text-center flex flex-col justify-between">
                        <div>
                            <h4 class="font-bold text-sm text-slate-100">Criar Nova Sala</h4>
                            <p class="text-[11px] text-blue-200/70 mt-1">Gera um código instantâneo para jogar.</p>
                        </div>
                        <button onclick="createOnlineRoom()" class="mt-3 w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-all shadow-md cursor-pointer">
                            <i class="fa-solid fa-plus-circle mr-1"></i> Criar Sala
                        </button>
                    </div>
                    <div class="bg-[#081533]/90 border border-blue-800/60 p-4 rounded-2xl text-center flex flex-col justify-between">
                        <div>
                            <h4 class="font-bold text-sm text-slate-100">Entrar com Código</h4>
                            <p class="text-[11px] text-blue-200/70 mt-1">Cole o código do seu amigo.</p>
                        </div>
                        <div class="flex gap-2 mt-3">
                            <input id="room-code-input" type="text" placeholder="Ex: CHESS-8321" class="bg-[#040c1e] border border-blue-800 px-3 py-1.5 rounded-xl text-xs font-mono text-center uppercase tracking-widest text-cyan-300 w-full focus:outline-none focus:border-cyan-400">
                            <button onclick="joinOnlineRoom()" class="bg-cyan-600 hover:bg-cyan-500 text-white font-bold px-4 rounded-xl text-xs cursor-pointer">
                                Entrar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- HUD Overlay Top Bar -->
    <div id="ui-overlay" class="fixed top-4 left-1/2 -translate-x-1/2 z-30 flex items-center gap-3 bg-[#081329]/90 border border-blue-600/30 backdrop-blur-xl px-4 py-2.5 rounded-2xl shadow-2xl shadow-blue-950/60 max-w-[95vw]">
        <button onclick="openMenu()" class="p-2 bg-blue-950/70 hover:bg-blue-900/60 rounded-xl text-slate-300 hover:text-white border border-blue-900/40 transition-all cursor-pointer" title="Menu Inicial">
            <i class="fa-solid fa-house"></i>
        </button>

        <div class="flex items-center gap-2.5 border-l border-blue-900/50 pl-3">
            <div id="turn-dot" class="w-3 h-3 rounded-full bg-white border border-slate-300 shadow-[0_0_8px_rgba(255,255,255,0.8)]"></div>
            <div class="flex flex-col">
                <h1 id="game-title-hud" class="font-bold text-xs text-white leading-tight">vs Pipoca (Nível 1)</h1>
                <p id="status" class="text-[11px] text-cyan-300 font-semibold">Vez das Brancas</p>
            </div>
        </div>

        <div class="h-6 w-[1px] bg-blue-900/50 mx-1 hidden sm:block"></div>

        <!-- Camera Preset Buttons -->
        <div class="hidden sm:flex items-center gap-1 bg-blue-950/50 p-1 rounded-xl border border-blue-900/40">
            <button onclick="setCameraView('white')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold text-slate-300 hover:text-white cursor-pointer">Brancas</button>
            <button onclick="setCameraView('black')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold text-slate-300 hover:text-white cursor-pointer">Pretas</button>
            <button onclick="setCameraView('top')" class="px-2.5 py-1 rounded-lg text-[11px] font-bold text-slate-300 hover:text-white cursor-pointer">Tático 2D</button>
        </div>

        <div class="h-6 w-[1px] bg-blue-900/50 mx-1"></div>

        <div class="flex items-center gap-1.5">
            <!-- Sound Test & Audio Settings -->
            <button onclick="openAudioSettings()" class="p-2 rounded-xl bg-blue-950/70 hover:bg-blue-900/60 text-slate-300 hover:text-cyan-300 border border-blue-900/40 transition-all cursor-pointer" title="Configurar Sons">
                <i class="fa-solid fa-music"></i>
            </button>
            <!-- Restart Button -->
            <button onclick="resetGame()" class="p-2 rounded-xl bg-blue-950/70 hover:bg-blue-900/60 text-slate-300 hover:text-white border border-blue-900/40 transition-all cursor-pointer" title="Reiniciar Partida">
                <i class="fa-solid fa-rotate-right"></i>
            </button>
            <!-- Resign Button -->
            <button onclick="handleResign()" class="p-2 rounded-xl bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-900/40 transition-all cursor-pointer" title="Render-se">
                <i class="fa-solid fa-flag"></i>
            </button>
        </div>
    </div>

    <!-- Room Badge -->
    <div id="room-badge" class="fixed top-4 right-4 z-30 hidden bg-[#081329]/90 border border-cyan-500/40 backdrop-blur-xl px-3.5 py-2 rounded-2xl shadow-xl flex items-center gap-2">
        <div class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
        <span class="text-xs text-slate-400">Sala:</span>
        <span id="room-code-display" class="font-mono text-xs font-bold text-cyan-300 tracking-wider">CHESS-0000</span>
        <button onclick="copyRoomCode()" class="p-1 rounded-md text-slate-400 hover:text-white cursor-pointer" title="Copiar Código">
            <i class="fa-regular fa-copy"></i>
        </button>
    </div>

    <!-- Captured Tray (Top Left) -->
    <div id="captured-tray" class="fixed top-20 left-4 z-20 flex flex-col gap-2 bg-[#09152e]/85 backdrop-blur-md border border-blue-900/50 p-2.5 rounded-2xl shadow-xl text-xs max-w-xs">
        <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-slate-100 border border-slate-300"></span>
                <span class="font-semibold text-slate-200">Brancas</span>
            </div>
            <div id="white-captures-list" class="flex items-center gap-0.5 text-slate-300 text-sm font-serif">
                <span class="text-[10px] text-slate-500 italic">Nenhuma captura</span>
            </div>
        </div>
        <div class="h-[1px] bg-blue-900/40 w-full"></div>
        <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-1.5">
                <span class="w-2.5 h-2.5 rounded-full bg-slate-900 border border-blue-400"></span>
                <span class="font-semibold text-slate-200">Pretas</span>
            </div>
            <div id="black-captures-list" class="flex items-center gap-0.5 text-slate-400 text-sm font-serif">
                <span class="text-[10px] text-slate-500 italic">Nenhuma captura</span>
            </div>
        </div>
    </div>

    <!-- Chat Box -->
    <div id="chat-container" class="fixed bottom-4 left-4 z-20 w-80 max-w-[calc(100vw-2rem)] bg-[#09152e]/90 border border-blue-900/60 backdrop-blur-xl rounded-2xl shadow-2xl flex flex-col overflow-hidden transition-all duration-300">
        <div class="bg-[#0b1b3d] px-3.5 py-2.5 border-b border-blue-900/50 flex items-center justify-between">
            <div class="flex items-center gap-2">
                <span id="chat-avatar" class="text-sm">🍿</span>
                <span id="chat-title" class="text-xs font-bold text-slate-100">Chat - Pipoca</span>
            </div>
            <button onclick="toggleChatCollapse()" class="text-slate-400 hover:text-white p-1 rounded-lg">
                <i id="chat-collapse-icon" class="fa-solid fa-chevron-down text-xs"></i>
            </button>
        </div>
        <div id="chat-messages" class="h-36 overflow-y-auto p-3 flex flex-col gap-2.5 text-xs text-slate-300">
            <div class="text-slate-500 text-[11px] text-center italic">A partida começou! Envie uma mensagem.</div>
        </div>
        <form onsubmit="sendUserChatMessage(event)" class="p-2 border-t border-blue-900/50 bg-[#071329] flex gap-2">
            <input id="chat-input" type="text" placeholder="Digite no chat..." class="flex-1 bg-slate-950/70 border border-blue-900/60 px-3 py-1.5 rounded-xl text-xs text-slate-100 focus:outline-none focus:border-cyan-400">
            <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white px-3 py-1.5 rounded-xl text-xs transition-all cursor-pointer">
                <i class="fa-solid fa-paper-plane"></i>
            </button>
        </form>
    </div>

    <!-- Game Over Modal (Victory / Defeat with sounds) -->
    <div id="custom-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 hidden">
        <div class="relative bg-gradient-to-b from-[#0c1c3d] to-[#060e21] border border-blue-500/40 rounded-3xl p-6 md:p-8 max-w-md w-full shadow-2xl shadow-blue-900/50 text-center flex flex-col items-center overflow-hidden">
            <div id="modal-icon" class="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-4 shadow-xl">
                🏆
            </div>
            <div id="modal-badge" class="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2 border">
                Vitória dos Campeões!
            </div>
            <h2 id="modal-title" class="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
                VOCÊ VENCEU! 🎉
            </h2>
            <p id="modal-message" class="text-slate-300 text-sm mt-2 max-w-xs leading-relaxed">
                Tocando a trilha especial de celebração!
            </p>

            <!-- Audio Controller Banner -->
            <div class="mt-6 w-full p-3 bg-blue-950/40 border border-blue-900/60 rounded-xl flex items-center justify-between text-xs">
                <div class="flex items-center gap-2 text-slate-300">
                    <span id="modal-audio-icon" class="text-base">🎵</span>
                    <span id="modal-audio-title" class="font-medium truncate">Intro UEFA Champions League</span>
                </div>
                <button onclick="toggleEndAudio()" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600/30 hover:bg-blue-600/50 border border-blue-400/40 text-cyan-200 font-semibold cursor-pointer transition-all">
                    <i id="modal-audio-btn-icon" class="fa-solid fa-volume-high text-cyan-400"></i>
                    <span id="modal-audio-btn-text">Pausar</span>
                </button>
            </div>

            <div class="flex flex-col sm:flex-row gap-3 w-full mt-6">
                <button onclick="closeModal(); resetGame();" class="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer transition-all text-sm">
                    <i class="fa-solid fa-rotate-right"></i>
                    <span>Revanche / Jogar</span>
                </button>
                <button onclick="closeModal(); openMenu();" class="bg-[#0b1733] hover:bg-[#12244f] text-slate-200 border border-blue-900/60 font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-all text-sm">
                    <i class="fa-solid fa-house"></i>
                    <span>Menu Inicial</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Audio Settings Modal -->
    <div id="audio-settings-modal" class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 hidden">
        <div class="bg-[#09152e] border border-blue-600/40 rounded-3xl p-6 max-w-md w-full shadow-2xl relative text-left">
            <button onclick="closeAudioSettings()" class="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-xl cursor-pointer">
                <i class="fa-solid fa-xmark text-lg"></i>
            </button>
            <div class="flex items-center gap-2 mb-4">
                <div class="p-2 rounded-xl bg-blue-600/20 text-cyan-400 border border-blue-500/30">
                    <i class="fa-solid fa-music"></i>
                </div>
                <div>
                    <h3 class="text-lg font-bold text-white">Configurações de Áudio & Músicas</h3>
                    <p class="text-xs text-slate-400">Trilhas de vitória, derrota e efeitos sonoros</p>
                </div>
            </div>

            <div class="flex flex-col gap-2.5">
                <!-- Test Victory -->
                <div class="flex items-center justify-between p-3 rounded-xl bg-blue-950/40 border border-blue-900/60">
                    <div class="flex items-center gap-2.5">
                        <span class="text-lg">🏆</span>
                        <div>
                            <p class="text-xs font-bold text-slate-100">Música de Vitória</p>
                            <p class="text-[11px] text-cyan-400 font-medium">Intro UEFA Champions League</p>
                        </div>
                    </div>
                    <button id="btn-test-victory" onclick="testTrack('victory')" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-semibold cursor-pointer">
                        <i class="fa-solid fa-play text-xs"></i> <span>Ouvir</span>
                    </button>
                </div>

                <!-- Test Defeat -->
                <div class="flex items-center justify-between p-3 rounded-xl bg-blue-950/40 border border-blue-900/60">
                    <div class="flex items-center gap-2.5">
                        <span class="text-lg">🪑</span>
                        <div>
                            <p class="text-xs font-bold text-slate-100">Música de Derrota</p>
                            <p class="text-[11px] text-red-400 font-medium">Pegue seu Banquinho - Raul Gil</p>
                        </div>
                    </div>
                    <button id="btn-test-defeat" onclick="testTrack('defeat')" class="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 text-xs font-semibold cursor-pointer">
                        <i class="fa-solid fa-play text-xs"></i> <span>Ouvir</span>
                    </button>
                </div>
            </div>

            <div class="mt-5 flex justify-end">
                <button onclick="closeAudioSettings()" class="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold cursor-pointer">
                    Concluir
                </button>
            </div>
        </div>
    </div>

    <!-- Three.js and Chess.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/chess.js/0.10.3/chess.min.js"></script>
"""

template_script = f"""
    <script>
        // EMBEDDED AUDIO BASE64 TRACKS
        const AUDIO_UEFA_B64 = "data:audio/mp3;base64,{uefa_b64}";
        const AUDIO_BANQUINHO_B64 = "data:audio/mp3;base64,{banquinho_b64}";

        const victoryAudio = new Audio(AUDIO_UEFA_B64);
        const defeatAudio = new Audio(AUDIO_BANQUINHO_B64);
        let currentTesting = null;

        function playVictorySound() {{
            stopAllAudios();
            victoryAudio.currentTime = 0;
            victoryAudio.play().catch(e => console.log(e));
        }}

        function playDefeatSound() {{
            stopAllAudios();
            defeatAudio.currentTime = 0;
            defeatAudio.play().catch(e => console.log(e));
        }}

        function stopAllAudios() {{
            victoryAudio.pause();
            defeatAudio.pause();
        }}

        function testTrack(track) {{
            const btnV = document.getElementById("btn-test-victory");
            const btnD = document.getElementById("btn-test-defeat");

            if (currentTesting === track) {{
                stopAllAudios();
                currentTesting = null;
                btnV.innerHTML = "<i class='fa-solid fa-play text-xs'></i> <span>Ouvir</span>";
                btnD.innerHTML = "<i class='fa-solid fa-play text-xs'></i> <span>Ouvir</span>";
            }} else {{
                stopAllAudios();
                currentTesting = track;
                if (track === "victory") {{
                    playVictorySound();
                    btnV.innerHTML = "<i class='fa-solid fa-stop text-xs'></i> <span>Parar</span>";
                    btnD.innerHTML = "<i class='fa-solid fa-play text-xs'></i> <span>Ouvir</span>";
                }} else {{
                    playDefeatSound();
                    btnD.innerHTML = "<i class='fa-solid fa-stop text-xs'></i> <span>Parar</span>";
                    btnV.innerHTML = "<i class='fa-solid fa-play text-xs'></i> <span>Ouvir</span>";
                }}
            }}
        }}

        function openAudioSettings() {{
            document.getElementById("audio-settings-modal").classList.remove("hidden");
        }}

        function closeAudioSettings() {{
            stopAllAudios();
            currentTesting = null;
            document.getElementById("audio-settings-modal").classList.add("hidden");
        }}

        function toggleEndAudio() {{
            const icon = document.getElementById("modal-audio-btn-icon");
            const text = document.getElementById("modal-audio-btn-text");
            if (!victoryAudio.paused || !defeatAudio.paused) {{
                stopAllAudios();
                icon.className = "fa-solid fa-volume-xmark text-slate-400";
                text.innerText = "Ouvir";
            }} else {{
                if (currentGameOverIsWin) {{
                    playVictorySound();
                }} else {{
                    playDefeatSound();
                }}
                icon.className = "fa-solid fa-volume-high text-cyan-400";
                text.innerText = "Pausar";
            }}
        }}

        // Web Audio Synthesizer for piece clicks
        function playClickSound() {{
            try {{
                const AudioCtx = window.AudioContext || window.webkitAudioContext;
                if (!AudioCtx) return;
                const ctx = new AudioCtx();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(320, ctx.currentTime);
                osc.frequency.exponentialRampToValueAtTime(140, ctx.currentTime + 0.08);
                gain.gain.setValueAtTime(0.2, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 0.08);
            }} catch(e){{}}
        }}

        // CHESS 3D LOGIC
        let scene, camera, renderer, controls;
        let chess = new Chess();
        let boardSquares = [];
        let pieceMeshes = {{}};
        let selectedSquare = null;
        let possibleMoves = [];
        let highlightMeshes = [];
        let currentGameMode = 'BOT';
        let currentBotLevel = 1;
        let playerColor = 'w';
        let currentGameOverIsWin = false;
        let onlineRoomCode = null;

        const squareSize = 1.15;
        const boardOffset = 4.025;

        const theme = {{
            table: 0x081329,
            tableBorder: 0x132a52,
            borderGlow: 0x2563eb,
            lightSquare: 0xdbeafe,
            darkSquare: 0x0f224a,
            selected: 0x38bdf8,
            possibleMove: 0x60a5fa,
            captureMove: 0xef4444,
            whitePiece: 0xf8fafc,
            blackPiece: 0x0b1324
        }};

        const BOT_PROFILES = {{
            1: {{ name: "Pipoca", avatar: "🍿", intro: "Oi! Sou o Pipoca! Vamos jogar bem divertido? 😊" }},
            2: {{ name: "Sr. Faísca", avatar: "⚡", intro: "Cuidado com minhas faíscas! Não vou facilitar! ⚡" }},
            3: {{ name: "Mestra Sophia", avatar: "🔮", intro: "Olá. O xadrez é a arte da paciência e harmonia." }},
            4: {{ name: "Tytan 9000", avatar: "🤖", intro: "Sistemas calculados. Probabilidade humana: reduzida." }},
            5: {{ name: "Zenith", avatar: "👑", intro: "Bem-vindo ao ápice. Mostre-me sua melhor versão." }}
        }};

        window.onload = function() {{
            initScene();
            animate();
        }};

        function initScene() {{
            scene = new THREE.Scene();
            scene.background = new THREE.Color(0x030714);
            scene.fog = new THREE.FogExp2(0x030714, 0.025);

            camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
            camera.position.set(0, 14, 12);

            renderer = new THREE.WebGLRenderer({{ antialias: true }});
            renderer.setSize(window.innerWidth, window.innerHeight);
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            renderer.shadowMap.enabled = true;
            renderer.shadowMap.type = THREE.PCFSoftShadowMap;
            document.body.appendChild(renderer.domElement);

            controls = new THREE.OrbitControls(camera, renderer.domElement);
            controls.enableDamping = true;
            controls.dampingFactor = 0.05;
            controls.maxPolarAngle = Math.PI / 2 - 0.02;
            controls.minDistance = 6;
            controls.maxDistance = 24;
            controls.target.set(0, 0, 0);

            const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
            scene.add(ambientLight);

            const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
            dirLight.position.set(12, 22, 14);
            dirLight.castShadow = true;
            dirLight.shadow.mapSize.width = 2048;
            dirLight.shadow.mapSize.height = 2048;
            scene.add(dirLight);

            const rimLight = new THREE.PointLight(theme.borderGlow, 1.8, 35);
            rimLight.position.set(-10, 10, -12);
            scene.add(rimLight);

            // Table in deep dark blue
            const tableGeo = new THREE.BoxGeometry(14.5, 0.9, 14.5);
            const tableMat = new THREE.MeshStandardMaterial({{ color: theme.table, roughness: 0.35, metalness: 0.3 }});
            const table = new THREE.Mesh(tableGeo, tableMat);
            table.position.y = -0.55;
            table.receiveShadow = true;
            scene.add(table);

            const borderGeo = new THREE.BoxGeometry(10.6, 0.32, 10.6);
            const borderMat = new THREE.MeshStandardMaterial({{ color: theme.tableBorder, roughness: 0.25, metalness: 0.5 }});
            const border = new THREE.Mesh(borderGeo, borderMat);
            border.position.y = -0.16;
            border.receiveShadow = true;
            scene.add(border);

            createBoardGrid();
            setupPieces();

            window.addEventListener('resize', onWindowResize);
            window.addEventListener('pointerdown', onPointerDown);
        }}

        function createBoardGrid() {{
            const geometry = new THREE.BoxGeometry(squareSize, 0.2, squareSize);
            for (let row = 0; row < 8; row++) {{
                for (let col = 0; col < 8; col++) {{
                    const isLight = (row + col) % 2 === 0;
                    const mat = new THREE.MeshStandardMaterial({{
                        color: isLight ? theme.lightSquare : theme.darkSquare,
                        roughness: 0.28,
                        metalness: isLight ? 0.15 : 0.45
                    }});
                    const square = new THREE.Mesh(geometry, mat);
                    square.position.set(col * squareSize - boardOffset, 0, row * squareSize - boardOffset);
                    square.receiveShadow = true;
                    const file = String.fromCharCode(97 + col);
                    const rank = 8 - row;
                    square.userData = {{ square: file + rank, row, col }};
                    scene.add(square);
                    boardSquares.push(square);
                }}
            }}
        }}

        function createPieceGeometry(type, color) {{
            const group = new THREE.Group();
            const isWhite = color === 'w';
            const mat = new THREE.MeshStandardMaterial({{
                color: isWhite ? theme.whitePiece : theme.blackPiece,
                roughness: isWhite ? 0.25 : 0.2,
                metalness: isWhite ? 0.35 : 0.65
            }});
            const goldMat = new THREE.MeshStandardMaterial({{
                color: isWhite ? 0xf59e0b : 0x38bdf8,
                metalness: 0.8,
                roughness: 0.2
            }});

            const base = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.46, 0.14, 28), mat);
            base.position.y = 0.07;
            group.add(base);

            switch(type) {{
                case 'p':
                    const bodyP = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.36, 0.45, 20), mat);
                    bodyP.position.y = 0.38;
                    const ringP = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.06, 20), goldMat);
                    ringP.position.y = 0.58;
                    const headP = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 20), mat);
                    headP.position.y = 0.74;
                    group.add(bodyP, ringP, headP);
                    break;
                case 'r':
                    const bodyR = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.38, 0.65, 24), mat);
                    bodyR.position.y = 0.45;
                    const topR = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.34, 0.22, 24), mat);
                    topR.position.y = 0.84;
                    group.add(bodyR, topR);
                    break;
                case 'n':
                    const bodyN = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.36, 0.45, 20), mat);
                    bodyN.position.y = 0.35;
                    const neck = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.45, 0.35), mat);
                    neck.position.set(0, 0.65, 0.06);
                    neck.rotation.x = -0.22;
                    group.add(bodyN, neck);
                    if (!isWhite) group.rotation.y = Math.PI;
                    break;
                case 'b':
                    const bodyB = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.36, 0.65, 22), mat);
                    bodyB.position.y = 0.46;
                    const middle = new THREE.Mesh(new THREE.SphereGeometry(0.26, 20, 20), mat);
                    middle.position.y = 0.82;
                    middle.scale.set(0.9, 1.3, 0.9);
                    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.08, 14, 14), goldMat);
                    tip.position.y = 1.12;
                    group.add(bodyB, middle, tip);
                    break;
                case 'q':
                    const bodyQ = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.38, 0.8, 24), mat);
                    bodyQ.position.y = 0.52;
                    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.24, 0.24, 24), mat);
                    crown.position.y = 0.98;
                    const jewel = new THREE.Mesh(new THREE.SphereGeometry(0.14, 16, 16), goldMat);
                    jewel.position.y = 1.18;
                    group.add(bodyQ, crown, jewel);
                    break;
                case 'k':
                    const bodyK = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.4, 0.92, 24), mat);
                    bodyK.position.y = 0.58;
                    const crownK = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.26, 0.26, 24), mat);
                    crownK.position.y = 1.1;
                    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.34, 0.08), goldMat);
                    crossV.position.y = 1.36;
                    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.09, 0.08), goldMat);
                    crossH.position.y = 1.38;
                    group.add(bodyK, crownK, crossV, crossH);
                    break;
            }}

            group.traverse(child => {{
                if (child.isMesh) {{
                    child.castShadow = true;
                    child.receiveShadow = true;
                }}
            }});
            return group;
        }}

        function setupPieces() {{
            Object.values(pieceMeshes).forEach(m => scene.remove(m));
            pieceMeshes = {{}};
            const board = chess.board();
            for (let r = 0; r < 8; r++) {{
                for (let c = 0; c < 8; c++) {{
                    const piece = board[r][c];
                    if (piece) {{
                        const file = String.fromCharCode(97 + c);
                        const rank = 8 - r;
                        const sq = file + rank;
                        const mesh = createPieceGeometry(piece.type, piece.color);
                        mesh.position.set(c * squareSize - boardOffset, 0, r * squareSize - boardOffset);
                        scene.add(mesh);
                        pieceMeshes[sq] = mesh;
                    }}
                }}
            }}
        }}

        const raycaster = new THREE.Raycaster();
        const pointer = new THREE.Vector2();

        function onPointerDown(event) {{
            if (event.target.closest('#ui-overlay') || event.target.closest('#chat-container') || event.target.closest('#welcome-screen') || event.target.closest('#custom-modal') || event.target.closest('#audio-settings-modal') || event.target.closest('#captured-tray')) return;
            if (currentGameMode === 'BOT' && chess.turn() !== playerColor) return;

            pointer.x = (event.clientX / window.innerWidth) * 2 - 1;
            pointer.y = -(event.clientY / window.innerHeight) * 2 + 1;
            raycaster.setFromCamera(pointer, camera);
            const intersects = raycaster.intersectObjects(boardSquares);

            if (intersects.length > 0) {{
                const clickedSquare = intersects[0].object.userData.square;
                handleSquareClick(clickedSquare);
            }}
        }}

        function handleSquareClick(square) {{
            const piece = chess.get(square);
            const isMoveValid = possibleMoves.some(m => m.to === square);

            if (selectedSquare && isMoveValid) {{
                executeMove(selectedSquare, square);
                clearHighlights();
                selectedSquare = null;
                possibleMoves = [];
                return;
            }}

            if (piece && piece.color === chess.turn()) {{
                clearHighlights();
                selectedSquare = square;
                possibleMoves = chess.moves({{ square: square, verbose: true }});
                highlightSquare(square, theme.selected);
                possibleMoves.forEach(m => highlightSquare(m.to, m.captured ? theme.captureMove : theme.possibleMove));
            }} else {{
                clearHighlights();
                selectedSquare = null;
                possibleMoves = [];
            }}
        }}

        function executeMove(source, target) {{
            const move = chess.move({{ from: source, to: target, promotion: 'q' }});
            if (move) {{
                playClickSound();
                setupPieces();
                updateStatus();
                updateCapturedDisplay();

                if (checkGameOver()) return;

                if (currentGameMode === 'BOT' && chess.turn() !== playerColor) {{
                    setTimeout(makeAIMove, 550);
                }}
            }}
        }}

        function makeAIMove() {{
            if (chess.game_over()) return;
            const moves = chess.moves({{ verbose: true }});
            if (moves.length === 0) return;

            let chosen = moves[Math.floor(Math.random() * moves.length)];
            const captures = moves.filter(m => !!m.captured);
            if (currentBotLevel > 1 && captures.length > 0) {{
                chosen = captures[Math.floor(Math.random() * captures.length)];
            }}

            chess.move(chosen);
            playClickSound();
            setupPieces();
            updateStatus();
            updateCapturedDisplay();

            const bot = BOT_PROFILES[currentBotLevel];
            addChatMessage(bot.name, "Movi minhas peças! Sua vez de jogar.", bot.avatar);

            checkGameOver();
        }}

        function highlightSquare(squareName, colorHex) {{
            const sq = boardSquares.find(s => s.userData.square === squareName);
            if (sq) {{
                const markerGeo = new THREE.BoxGeometry(squareSize * 0.94, 0.22, squareSize * 0.94);
                const markerMat = new THREE.MeshBasicMaterial({{ color: colorHex, transparent: true, opacity: 0.6 }});
                const marker = new THREE.Mesh(markerGeo, markerMat);
                marker.position.copy(sq.position);
                marker.position.y += 0.02;
                scene.add(marker);
                highlightMeshes.push(marker);
            }}
        }}

        function clearHighlights() {{
            highlightMeshes.forEach(m => scene.remove(m));
            highlightMeshes = [];
        }}

        function updateStatus() {{
            const statusDiv = document.getElementById('status');
            const turnDot = document.getElementById('turn-dot');
            const turn = chess.turn();

            if (turn === 'w') {{
                turnDot.className = "w-3 h-3 rounded-full bg-white border border-slate-300 shadow-[0_0_8px_rgba(255,255,255,0.8)]";
            }} else {{
                turnDot.className = "w-3 h-3 rounded-full bg-slate-900 border border-cyan-400 shadow-[0_0_8px_rgba(56,189,248,0.8)]";
            }}

            if (chess.in_checkmate()) {{
                statusDiv.innerText = "XEQUE-MATE!";
            }} else if (chess.in_draw()) {{
                statusDiv.innerText = "Empate!";
            }} else {{
                statusDiv.innerText = `Vez das ${{turn === 'w' ? 'Brancas' : 'Pretas'}}` + (chess.in_check() ? ' (XEQUE!)' : '');
            }}
        }}

        function updateCapturedDisplay() {{
            const fullSet = {{ p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 }};
            const cur = {{ w: {{ p:0,n:0,b:0,r:0,q:0,k:0 }}, b: {{ p:0,n:0,b:0,r:0,q:0,k:0 }} }};
            const b = chess.board();
            for (let r=0; r<8; r++) {{
                for (let c=0; c<8; c++) {{
                    const p = b[r][c];
                    if (p) cur[p.color][p.type]++;
                }}
            }}
            const sym = {{ p:'♟', n:'♞', b:'♝', r:'♜', q:'♛' }};
            let wStr = "", bStr = "";
            for (let t of ['p','n','b','r','q']) {{
                let lostW = fullSet[t] - cur.w[t];
                for (let i=0; i<lostW; i++) bStr += sym[t];
                let lostB = fullSet[t] - cur.b[t];
                for (let i=0; i<lostB; i++) wStr += sym[t];
            }}
            document.getElementById('white-captures-list').innerHTML = wStr || "<span class='text-[10px] text-slate-500 italic'>Nenhuma</span>";
            document.getElementById('black-captures-list').innerHTML = bStr || "<span class='text-[10px] text-slate-500 italic'>Nenhuma</span>";
        }}

        function checkGameOver() {{
            if (chess.game_over()) {{
                let isWin = false;
                let isDraw = chess.in_draw();

                if (chess.in_checkmate()) {{
                    const winner = chess.turn() === 'w' ? 'b' : 'w';
                    isWin = (currentGameMode === 'BOT') ? (winner === playerColor) : (winner === 'w');
                }}

                currentGameOverIsWin = isWin;
                const modal = document.getElementById('custom-modal');
                const title = document.getElementById('modal-title');
                const msg = document.getElementById('modal-message');
                const icon = document.getElementById('modal-icon');
                const badge = document.getElementById('modal-badge');
                const audioTitle = document.getElementById('modal-audio-title');
                const audioIcon = document.getElementById('modal-audio-icon');

                if (isWin) {{
                    icon.innerHTML = "🏆";
                    icon.className = "w-20 h-20 rounded-2xl bg-amber-500/20 text-4xl mb-4 shadow-xl text-amber-400 animate-bounce border border-amber-500/40";
                    badge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2 border bg-amber-500/20 text-amber-300 border-amber-500/40";
                    badge.innerText = "Vitória dos Campeões!";
                    title.innerText = "VOCÊ VENCEU! 🎉";
                    msg.innerHTML = "Tocando a gloriosa trilha da <strong class='text-cyan-300'>UEFA Champions League</strong>!";
                    audioIcon.innerText = "🏆";
                    audioTitle.innerText = "Intro UEFA Champions League";
                    playVictorySound();

                    confetti({{ particleCount: 80, spread: 70, origin: {{ y: 0.6 }} }});
                }} else if (isDraw) {{
                    icon.innerHTML = "🤝";
                    badge.innerText = "Empate Técnico";
                    title.innerText = "Empate!";
                    msg.innerText = "Uma partida muito equilibrada!";
                    audioTitle.innerText = "Fim de Jogo";
                }} else {{
                    icon.innerHTML = "🪑";
                    icon.className = "w-20 h-20 rounded-2xl bg-red-950/60 text-4xl mb-4 shadow-xl border border-red-500/40 animate-pulse";
                    badge.className = "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2 border bg-red-500/20 text-red-300 border-red-500/40";
                    badge.innerText = "Derrota no Tabuleiro";
                    title.innerHTML = "PEGUE SEU BANQUINHO!";
                    msg.innerHTML = "<span class='text-amber-300 font-semibold italic text-base'>... e saia de mansinho! 🎶</span><br>Hora de sacudir a poeira e tentar a revanche!";
                    audioIcon.innerText = "🪑";
                    audioTitle.innerText = "Pegue seu Banquinho - Raul Gil";
                    playDefeatSound();
                }}

                modal.classList.remove('hidden');
                return true;
            }}
            return false;
        }}

        function handleResign() {{
            currentGameOverIsWin = false;
            const modal = document.getElementById('custom-modal');
            document.getElementById('modal-icon').innerHTML = "🪑";
            document.getElementById('modal-title').innerText = "PEGUE SEU BANQUINHO!";
            document.getElementById('modal-message').innerHTML = "<span class='text-amber-300 font-semibold italic text-base'>... e saia de mansinho! 🎶</span><br>Você se rendeu da partida!";
            document.getElementById('modal-audio-title').innerText = "Pegue seu Banquinho - Raul Gil";
            playDefeatSound();
            modal.classList.remove('hidden');
        }}

        function closeModal() {{
            stopAllAudios();
            document.getElementById('custom-modal').classList.add('hidden');
        }}

        function resetGame() {{
            stopAllAudios();
            chess.reset();
            setupPieces();
            clearHighlights();
            selectedSquare = null;
            possibleMoves = [];
            updateStatus();
            updateCapturedDisplay();
            addChatMessage("Sistema", "A partida foi reiniciada!", "👑");
        }}

        function openMenu() {{
            document.getElementById('welcome-screen').classList.remove('hidden');
        }}

        function hideSubmenus() {{
            document.getElementById('bot-selection').classList.add('hidden');
            document.getElementById('bot-selection').classList.remove('flex');
            document.getElementById('online-selection').classList.add('hidden');
            document.getElementById('online-selection').classList.remove('flex');
        }}

        function showBotSelection() {{
            hideSubmenus();
            const el = document.getElementById('bot-selection');
            el.classList.remove('hidden');
            el.classList.add('flex');
        }}

        function showOnlineSetup() {{
            hideSubmenus();
            const el = document.getElementById('online-selection');
            el.classList.remove('hidden');
            el.classList.add('flex');
        }}

        function startLocalGame() {{
            currentGameMode = 'LOCAL';
            document.getElementById('welcome-screen').classList.add('hidden');
            document.getElementById('game-title-hud').innerText = "2 Jogadores Local";
            resetGame();
        }}

        function selectBot(lvl) {{
            currentBotLevel = lvl;
            currentGameMode = 'BOT';
            document.getElementById('welcome-screen').classList.add('hidden');
            const bot = BOT_PROFILES[lvl];
            document.getElementById('game-title-hud').innerText = `vs ${{bot.name}} (Nível ${{lvl}})`;
            document.getElementById('chat-title').innerText = `Chat - ${{bot.name}}`;
            document.getElementById('chat-avatar').innerText = bot.avatar;
            resetGame();
            addChatMessage(bot.name, bot.intro, bot.avatar);
        }}

        function createOnlineRoom() {{
            onlineRoomCode = "CHESS-" + Math.floor(1000 + Math.random() * 9000);
            currentGameMode = 'ONLINE';
            document.getElementById('welcome-screen').classList.add('hidden');
            document.getElementById('room-code-display').innerText = onlineRoomCode;
            document.getElementById('room-badge').classList.remove('hidden');
            document.getElementById('game-title-hud').innerText = "Sala Online";
            resetGame();
            addChatMessage("Sistema", `Sala ${{onlineRoomCode}} criada! Compartilhe com seu amigo.`, "🌐");
        }}

        function joinOnlineRoom() {{
            const inp = document.getElementById('room-code-input').value.trim().toUpperCase();
            if (!inp) return;
            onlineRoomCode = inp;
            currentGameMode = 'ONLINE';
            document.getElementById('welcome-screen').classList.add('hidden');
            document.getElementById('room-code-display').innerText = onlineRoomCode;
            document.getElementById('room-badge').classList.remove('hidden');
            document.getElementById('game-title-hud').innerText = "Sala Online";
            resetGame();
            addChatMessage("Sistema", `Conectado à sala ${{onlineRoomCode}}!`, "🌐");
        }}

        function copyRoomCode() {{
            if (onlineRoomCode) {{
                navigator.clipboard.writeText(onlineRoomCode);
                alert("Código da sala copiado: " + onlineRoomCode);
            }}
        }}

        function setCameraView(view) {{
            let targetPos = {{ x: 0, y: 14, z: 12 }};
            if (view === 'black') targetPos = {{ x: 0, y: 14, z: -12 }};
            if (view === 'top') targetPos = {{ x: 0, y: 18, z: 0.01 }};
            camera.position.set(targetPos.x, targetPos.y, targetPos.z);
            camera.lookAt(0, 0, 0);
        }}

        function addChatMessage(sender, text, avatar = "💬") {{
            const container = document.getElementById('chat-messages');
            const el = document.createElement('div');
            el.className = "flex flex-col gap-0.5 leading-snug";
            el.innerHTML = `
                <div class="flex items-center gap-1.5">
                    <span class="text-xs">${{avatar}}</span>
                    <span class="font-bold text-[11px] text-cyan-300">${{sender}}</span>
                </div>
                <div class="text-slate-200 text-xs bg-blue-950/50 border border-blue-900/40 p-2 rounded-xl">${{text}}</div>
            `;
            container.appendChild(el);
            container.scrollTop = container.scrollHeight;
        }}

        function sendUserChatMessage(e) {{
            e.preventDefault();
            const inp = document.getElementById('chat-input');
            const txt = inp.value.trim();
            if (!txt) return;
            addChatMessage("Você", txt, "👤");
            inp.value = "";
            if (currentGameMode === 'BOT') {{
                setTimeout(() => {{
                    const bot = BOT_PROFILES[currentBotLevel];
                    addChatMessage(bot.name, "Estou pensando nas melhores jogadas no tabuleiro!", bot.avatar);
                }}, 800);
            }}
        }}

        function toggleChatCollapse() {{
            const c = document.getElementById('chat-messages');
            const ic = document.getElementById('chat-collapse-icon');
            if (c.classList.contains('hidden')) {{
                c.classList.remove('hidden');
                ic.className = "fa-solid fa-chevron-down text-xs";
            }} else {{
                c.classList.add('hidden');
                ic.className = "fa-solid fa-chevron-up text-xs";
            }}
        }}

        function onWindowResize() {{
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        }}

        function animate() {{
            requestAnimationFrame(animate);
            controls.update();
            renderer.render(scene, camera);
        }}
    </script>
</body>
</html>
"""

full_html = template_head + template_script

with open("public/xadrez-3d-master.html", "w", encoding="utf-8") as f:
    f.write(full_html)

print("Generated public/xadrez-3d-master.html! Size:", os.path.getsize("public/xadrez-3d-master.html"))
