import React, { useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Chess, Square, Move } from 'chess.js';
import { PieceColor } from '../types/chess';
import { soundManager } from '../utils/soundEffects';

interface Chess3DCanvasProps {
  chess: Chess;
  playerColor: PieceColor;
  onSquareClick: (square: Square) => void;
  selectedSquare: Square | null;
  possibleMoves: Move[];
  lastMove: { from: string; to: string } | null;
  cameraPreset: 'white' | 'black' | 'top' | 'free';
  onCameraPresetChanged?: () => void;
}

export const Chess3DCanvas: React.FC<Chess3DCanvasProps> = ({
  chess,
  playerColor,
  onSquareClick,
  selectedSquare,
  possibleMoves,
  lastMove,
  cameraPreset
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);

  const boardSquaresRef = useRef<THREE.Mesh[]>([]);
  const pieceMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const highlightsGroupRef = useRef<THREE.Group>(new THREE.Group());
  const hoverMarkerRef = useRef<THREE.Mesh | null>(null);

  // Interaction tracking to differentiate click from orbit drag
  const pointerDownPos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const isDragging = useRef<boolean>(false);

  const squareSize = 1.15;
  const boardOffset = 4.025; // 3.5 * squareSize

  // Modern Dark Blue & Sapphire Theme Colors
  const theme = {
    bg: 0x030714,
    fog: 0x030714,
    table: 0x081329,
    tableBorder: 0x132a52,
    borderGlow: 0x2563eb,
    lightSquare: 0xdbeafe, // Soft frosted ice-white
    darkSquare: 0x0f224a,  // Deep sapphire navy
    selected: 0x38bdf8,    // Electric cyan
    possibleMove: 0x60a5fa,// Glowing light blue
    captureMove: 0xef4444, // Warning crimson
    lastMove: 0x1e3a8a,    // Navy highlight
    checkWarning: 0xf59e0b,// Amber-gold warning
    whitePiece: 0xf8fafc,  // Crisp pearl ivory
    whitePieceEmissive: 0x1e293b,
    blackPiece: 0x0b1324,  // Polished midnight navy
    blackPieceEmissive: 0x020617
  };

  // Helper to get 3D coords for a square
  const getSquareCoords = useCallback((sq: string) => {
    const col = sq.charCodeAt(0) - 97; // 0 to 7 (a to h)
    const row = 8 - parseInt(sq[1], 10); // 0 to 7 (8 to 1)
    return {
      x: col * squareSize - boardOffset,
      z: row * squareSize - boardOffset
    };
  }, [squareSize, boardOffset]);

  // Create piece 3D geometry
  const createPieceMesh = useCallback((type: string, color: 'w' | 'b') => {
    const group = new THREE.Group();
    const isWhite = color === 'w';

    const mat = new THREE.MeshStandardMaterial({
      color: isWhite ? theme.whitePiece : theme.blackPiece,
      roughness: isWhite ? 0.25 : 0.2,
      metalness: isWhite ? 0.35 : 0.65,
      envMapIntensity: 1.2
    });

    const goldAccentMat = new THREE.MeshStandardMaterial({
      color: isWhite ? 0xf59e0b : 0x38bdf8,
      metalness: 0.8,
      roughness: 0.2
    });

    // Base pedestal
    const baseCylinder = new THREE.Mesh(
      new THREE.CylinderGeometry(0.42, 0.46, 0.14, 28),
      mat
    );
    baseCylinder.position.y = 0.07;
    group.add(baseCylinder);

    const baseRing = new THREE.Mesh(
      new THREE.TorusGeometry(0.38, 0.035, 12, 28),
      goldAccentMat
    );
    baseRing.rotation.x = Math.PI / 2;
    baseRing.position.y = 0.14;
    group.add(baseRing);

    switch (type) {
      case 'p': { // Pawn
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.36, 0.45, 20), mat);
        body.position.y = 0.38;
        const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.06, 20), goldAccentMat);
        ring.position.y = 0.58;
        const head = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 20), mat);
        head.position.y = 0.74;
        group.add(body, ring, head);
        break;
      }
      case 'r': { // Rook
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.38, 0.65, 24), mat);
        body.position.y = 0.45;
        const topR = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.34, 0.22, 24), mat);
        topR.position.y = 0.84;

        // Crenellations (turrets)
        for (let i = 0; i < 4; i++) {
          const turret = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.1, 0.12), goldAccentMat);
          const angle = (i * Math.PI) / 2;
          turret.position.set(Math.cos(angle) * 0.28, 0.96, Math.sin(angle) * 0.28);
          group.add(turret);
        }
        group.add(body, topR);
        break;
      }
      case 'n': { // Knight (Horse)
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.36, 0.45, 20), mat);
        body.position.y = 0.35;

        // Horse neck & head
        const neck = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.45, 0.35), mat);
        neck.position.set(0, 0.65, 0.06);
        neck.rotation.x = -0.22;

        const muzzle = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.24, 0.36), mat);
        muzzle.position.set(0, 0.78, 0.24);
        muzzle.rotation.x = 0.18;

        const mane = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.42, 0.12), goldAccentMat);
        mane.position.set(0, 0.7, -0.12);

        // Ears
        const earL = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.14, 8), mat);
        earL.position.set(0.08, 0.96, 0.08);
        const earR = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.14, 8), mat);
        earR.position.set(-0.08, 0.96, 0.08);

        group.add(body, neck, muzzle, mane, earL, earR);
        // Turn knight towards opposing side
        if (isWhite) {
          group.rotation.y = 0;
        } else {
          group.rotation.y = Math.PI;
        }
        break;
      }
      case 'b': { // Bishop
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.36, 0.65, 22), mat);
        body.position.y = 0.46;
        const middle = new THREE.Mesh(new THREE.SphereGeometry(0.26, 20, 20), mat);
        middle.position.y = 0.82;
        middle.scale.set(0.9, 1.3, 0.9);
        const tip = new THREE.Mesh(new THREE.SphereGeometry(0.08, 14, 14), goldAccentMat);
        tip.position.y = 1.12;
        group.add(body, middle, tip);
        break;
      }
      case 'q': { // Queen
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.38, 0.8, 24), mat);
        body.position.y = 0.52;
        const crownBase = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.24, 0.24, 24), mat);
        crownBase.position.y = 0.98;

        const crownJewel = new THREE.Mesh(new THREE.SphereGeometry(0.14, 16, 16), goldAccentMat);
        crownJewel.position.y = 1.18;

        // Crown spikes
        for (let i = 0; i < 6; i++) {
          const spike = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 10), goldAccentMat);
          const angle = (i * Math.PI) / 3;
          spike.position.set(Math.cos(angle) * 0.32, 1.1, Math.sin(angle) * 0.32);
          group.add(spike);
        }

        group.add(body, crownBase, crownJewel);
        break;
      }
      case 'k': { // King
        const body = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.4, 0.92, 24), mat);
        body.position.y = 0.58;
        const crownBase = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.26, 0.26, 24), mat);
        crownBase.position.y = 1.1;

        // Royal cross
        const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.34, 0.08), goldAccentMat);
        crossV.position.y = 1.36;
        const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.09, 0.08), goldAccentMat);
        crossH.position.y = 1.38;

        group.add(body, crownBase, crossV, crossH);
        break;
      }
    }

    group.traverse((child) => {
      if ((child as THREE.Mesh).isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;
      }
    });

    return group;
  }, [theme.whitePiece, theme.blackPiece]);

  // Sync pieces with chess state
  const syncPieces = useCallback(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Remove existing pieces
    pieceMeshesRef.current.forEach((mesh) => scene.remove(mesh));
    pieceMeshesRef.current.clear();

    const board = chess.board();
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece) {
          const file = String.fromCharCode(97 + c);
          const rank = 8 - r;
          const sq = `${file}${rank}`;
          const coords = getSquareCoords(sq);

          const pieceMesh = createPieceMesh(piece.type, piece.color);
          pieceMesh.position.set(coords.x, 0, coords.z);
          pieceMesh.userData = { square: sq, type: piece.type, color: piece.color };

          scene.add(pieceMesh);
          pieceMeshesRef.current.set(sq, pieceMesh);
        }
      }
    }
  }, [chess, getSquareCoords, createPieceMesh]);

  // Update dynamic board highlights
  const updateHighlights = useCallback(() => {
    const group = highlightsGroupRef.current;
    // Clear old children
    while (group.children.length > 0) {
      group.remove(group.children[0]);
    }

    // 1. Last Move Highlights
    if (lastMove) {
      [lastMove.from, lastMove.to].forEach((sq) => {
        const coords = getSquareCoords(sq);
        const marker = new THREE.Mesh(
          new THREE.PlaneGeometry(squareSize * 0.94, squareSize * 0.94),
          new THREE.MeshBasicMaterial({
            color: theme.lastMove,
            transparent: true,
            opacity: 0.5,
            depthWrite: false
          })
        );
        marker.rotation.x = -Math.PI / 2;
        marker.position.set(coords.x, 0.11, coords.z);
        group.add(marker);
      });
    }

    // 2. Selected Square Highlight
    if (selectedSquare) {
      const coords = getSquareCoords(selectedSquare);
      // Glowing pillar / halo
      const selMesh = new THREE.Mesh(
        new THREE.CylinderGeometry(squareSize * 0.44, squareSize * 0.46, 0.05, 32),
        new THREE.MeshStandardMaterial({
          color: theme.selected,
          emissive: theme.selected,
          emissiveIntensity: 0.8,
          transparent: true,
          opacity: 0.85
        })
      );
      selMesh.position.set(coords.x, 0.13, coords.z);
      group.add(selMesh);
    }

    // 3. Possible Moves Highlights
    possibleMoves.forEach((move) => {
      const coords = getSquareCoords(move.to);
      const isCapture = !!move.captured;

      if (isCapture) {
        // Red warning capture ring
        const ringGeo = new THREE.RingGeometry(squareSize * 0.32, squareSize * 0.46, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: theme.captureMove,
          transparent: true,
          opacity: 0.85,
          side: THREE.DoubleSide,
          depthWrite: false
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(coords.x, 0.14, coords.z);
        group.add(ring);
      } else {
        // Glowing cyan disk
        const dotGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.04, 24);
        const dotMat = new THREE.MeshStandardMaterial({
          color: theme.possibleMove,
          emissive: theme.possibleMove,
          emissiveIntensity: 0.6,
          transparent: true,
          opacity: 0.8
        });
        const dot = new THREE.Mesh(dotGeo, dotMat);
        dot.position.set(coords.x, 0.13, coords.z);
        group.add(dot);
      }
    });

    // 4. King Check Indicator
    if (chess.inCheck()) {
      const board = chess.board();
      const currentTurn = chess.turn();
      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          const piece = board[r][c];
          if (piece && piece.type === 'k' && piece.color === currentTurn) {
            const file = String.fromCharCode(97 + c);
            const rank = 8 - r;
            const sq = `${file}${rank}`;
            const coords = getSquareCoords(sq);

            const checkGeo = new THREE.RingGeometry(squareSize * 0.25, squareSize * 0.48, 32);
            const checkMat = new THREE.MeshBasicMaterial({
              color: theme.checkWarning,
              transparent: true,
              opacity: 0.9,
              side: THREE.DoubleSide
            });
            const checkRing = new THREE.Mesh(checkGeo, checkMat);
            checkRing.rotation.x = -Math.PI / 2;
            checkRing.position.set(coords.x, 0.15, coords.z);
            group.add(checkRing);
          }
        }
      }
    }
  }, [
    selectedSquare,
    possibleMoves,
    lastMove,
    chess,
    getSquareCoords,
    squareSize,
    theme.lastMove,
    theme.selected,
    theme.captureMove,
    theme.possibleMove,
    theme.checkWarning
  ]);

  // Initialize Three.js scene
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(theme.bg);
    scene.fog = new THREE.FogExp2(theme.fog, 0.025);
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    // Start facing White side
    camera.position.set(0, 14, 12);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // 4. Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2 - 0.02; // Prevent going below table
    controls.minDistance = 6;
    controls.maxDistance = 24;
    controls.target.set(0, 0, 0);
    controlsRef.current = controls;

    // 5. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.75);
    scene.add(ambientLight);

    const mainLight = new THREE.DirectionalLight(0xffffff, 1.2);
    mainLight.position.set(12, 22, 14);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    mainLight.shadow.camera.near = 1;
    mainLight.shadow.camera.far = 40;
    const shadowD = 9;
    mainLight.shadow.camera.left = -shadowD;
    mainLight.shadow.camera.right = shadowD;
    mainLight.shadow.camera.top = shadowD;
    mainLight.shadow.camera.bottom = -shadowD;
    mainLight.shadow.bias = -0.0004;
    scene.add(mainLight);

    // Deep sapphire rim light
    const blueRimLight = new THREE.PointLight(theme.borderGlow, 1.8, 35);
    blueRimLight.position.set(-10, 10, -12);
    scene.add(blueRimLight);

    const cyanSoftLight = new THREE.PointLight(0x38bdf8, 1.0, 30);
    cyanSoftLight.position.set(10, 8, -10);
    scene.add(cyanSoftLight);

    // 6. Pedestal / Table in rich navy marble
    const tableGeo = new THREE.BoxGeometry(14.5, 0.9, 14.5);
    const tableMat = new THREE.MeshStandardMaterial({
      color: theme.table,
      roughness: 0.35,
      metalness: 0.3
    });
    const table = new THREE.Mesh(tableGeo, tableMat);
    table.position.y = -0.55;
    table.receiveShadow = true;
    scene.add(table);

    // Board Bevel Border with subtle sapphire glow line
    const borderGeo = new THREE.BoxGeometry(10.6, 0.32, 10.6);
    const borderMat = new THREE.MeshStandardMaterial({
      color: theme.tableBorder,
      roughness: 0.25,
      metalness: 0.5
    });
    const border = new THREE.Mesh(borderGeo, borderMat);
    border.position.y = -0.16;
    border.receiveShadow = true;
    border.castShadow = true;
    scene.add(border);

    // Glowing Neon Accent Frame
    const neonFrameGeo = new THREE.BoxGeometry(9.6, 0.05, 9.6);
    const neonFrameMat = new THREE.MeshStandardMaterial({
      color: theme.borderGlow,
      emissive: theme.borderGlow,
      emissiveIntensity: 0.4,
      roughness: 0.3
    });
    const neonFrame = new THREE.Mesh(neonFrameGeo, neonFrameMat);
    neonFrame.position.y = -0.02;
    scene.add(neonFrame);

    // 7. Chessboard Squares
    boardSquaresRef.current = [];
    const squareGeo = new THREE.BoxGeometry(squareSize, 0.2, squareSize);
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const isLight = (row + col) % 2 === 0;
        const mat = new THREE.MeshStandardMaterial({
          color: isLight ? theme.lightSquare : theme.darkSquare,
          roughness: 0.28,
          metalness: isLight ? 0.15 : 0.45
        });
        const square = new THREE.Mesh(squareGeo, mat);
        square.position.set(
          col * squareSize - boardOffset,
          0,
          row * squareSize - boardOffset
        );
        square.receiveShadow = true;

        const file = String.fromCharCode(97 + col);
        const rank = 8 - row;
        square.userData = { square: `${file}${rank}`, row, col };

        scene.add(square);
        boardSquaresRef.current.push(square);
      }
    }

    // 8. Highlights Group
    scene.add(highlightsGroupRef.current);

    // 9. Subtle Hover Marker
    const hoverGeo = new THREE.PlaneGeometry(squareSize * 0.96, squareSize * 0.96);
    const hoverMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0,
      depthWrite: false
    });
    const hoverMesh = new THREE.Mesh(hoverGeo, hoverMat);
    hoverMesh.rotation.x = -Math.PI / 2;
    hoverMesh.position.y = 0.11;
    scene.add(hoverMesh);
    hoverMarkerRef.current = hoverMesh;

    // 10. Initial pieces render
    syncPieces();

    // 11. Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    };
    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
      container.innerHTML = '';
    };
  }, []); // Run once on mount

  // Sync pieces when chess state changes
  useEffect(() => {
    syncPieces();
    updateHighlights();
  }, [chess, syncPieces, updateHighlights]);

  // Camera presets animation
  useEffect(() => {
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!camera || !controls) return;

    let targetPos = new THREE.Vector3(0, 14, 12);
    if (cameraPreset === 'white') {
      targetPos.set(0, 13, 11);
    } else if (cameraPreset === 'black') {
      targetPos.set(0, 13, -11);
    } else if (cameraPreset === 'top') {
      targetPos.set(0, 18, 0.01);
    } else {
      return; // Free mode
    }

    const startPos = camera.position.clone();
    let progress = 0;
    const animateCam = () => {
      progress += 0.06;
      camera.position.lerpVectors(startPos, targetPos, Math.min(1, progress));
      controls.target.set(0, 0, 0);
      camera.lookAt(0, 0, 0);
      if (progress < 1) {
        requestAnimationFrame(animateCam);
      }
    };
    animateCam();
  }, [cameraPreset]);

  // Pointer interactions (Raycasting for clicks and hover)
  const handlePointerDown = (e: React.PointerEvent) => {
    pointerDownPos.current = { x: e.clientX, y: e.clientY };
    isDragging.current = false;
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    const dx = Math.abs(e.clientX - pointerDownPos.current.x);
    const dy = Math.abs(e.clientY - pointerDownPos.current.y);
    if (dx > 5 || dy > 5) {
      isDragging.current = true;
    }

    // Raycast for hover effect
    const container = mountRef.current;
    const camera = cameraRef.current;
    const hoverMesh = hoverMarkerRef.current;
    if (!container || !camera || !hoverMesh || isDragging.current) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), camera);
    const intersects = raycaster.intersectObjects(boardSquaresRef.current);

    if (intersects.length > 0) {
      const sqObj = intersects[0].object as THREE.Mesh;
      hoverMesh.position.x = sqObj.position.x;
      hoverMesh.position.z = sqObj.position.z;
      (hoverMesh.material as THREE.MeshBasicMaterial).opacity = 0.25;
    } else {
      (hoverMesh.material as THREE.MeshBasicMaterial).opacity = 0;
    }
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (isDragging.current) return; // User was panning/rotating camera

    const container = mountRef.current;
    const camera = cameraRef.current;
    if (!container || !camera) return;

    const rect = container.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(new THREE.Vector2(x, y), camera);
    const intersects = raycaster.intersectObjects(boardSquaresRef.current);

    if (intersects.length > 0) {
      const sqObj = intersects[0].object as THREE.Mesh;
      const clickedSquare = sqObj.userData.square as Square;
      if (clickedSquare) {
        onSquareClick(clickedSquare);
      }
    }
  };

  return (
    <div
      ref={mountRef}
      className="w-full h-full cursor-grab active:cursor-grabbing outline-none"
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerLeave={() => {
        if (hoverMarkerRef.current) {
          (hoverMarkerRef.current.material as THREE.MeshBasicMaterial).opacity = 0;
        }
      }}
    />
  );
};
