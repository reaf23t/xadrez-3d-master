import React from 'react';
import { CapturedPieces } from '../types/chess';

interface CapturedTrayProps {
  captured: CapturedPieces;
  playerColor: 'w' | 'b';
}

const PIECE_SYMBOLS: Record<string, string> = {
  p: '♟',
  n: '♞',
  b: '♝',
  r: '♜',
  q: '♛'
};

const PIECE_VALUES: Record<string, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9
};

export const CapturedTray: React.FC<CapturedTrayProps> = ({ captured, playerColor }) => {
  // Pieces that White has captured (i.e. black pieces taken)
  const whiteCaptures = captured.b;
  // Pieces that Black has captured (i.e. white pieces taken)
  const blackCaptures = captured.w;

  const whiteScore = whiteCaptures.reduce((acc, p) => acc + (PIECE_VALUES[p] || 0), 0);
  const blackScore = blackCaptures.reduce((acc, p) => acc + (PIECE_VALUES[p] || 0), 0);

  const whiteDiff = whiteScore - blackScore;
  const blackDiff = blackScore - whiteScore;

  return (
    <div className="flex flex-col gap-2 bg-[#09152e]/85 backdrop-blur-md border border-blue-900/50 p-2.5 rounded-2xl shadow-xl text-xs max-w-xs">
      {/* White Team Tray */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-100 border border-slate-300"></span>
          <span className="font-semibold text-slate-200">Brancas</span>
          {whiteDiff > 0 && (
            <span className="px-1.5 py-0.5 rounded-md bg-blue-500/20 text-cyan-300 font-mono text-[10px] font-bold">
              +{whiteDiff}
            </span>
          )}
        </div>
        <div className="flex items-center gap-0.5 tracking-tight text-slate-300 text-sm font-serif">
          {whiteCaptures.length > 0 ? (
            whiteCaptures.map((p, idx) => (
              <span key={idx} className="opacity-80 hover:opacity-100" title={`Capturou ${p}`}>
                {PIECE_SYMBOLS[p] || p}
              </span>
            ))
          ) : (
            <span className="text-[10px] text-slate-500 italic">Nenhuma captura</span>
          )}
        </div>
      </div>

      <div className="h-[1px] bg-blue-900/40 w-full" />

      {/* Black Team Tray */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-blue-400"></span>
          <span className="font-semibold text-slate-200">Pretas</span>
          {blackDiff > 0 && (
            <span className="px-1.5 py-0.5 rounded-md bg-blue-500/20 text-cyan-300 font-mono text-[10px] font-bold">
              +{blackDiff}
            </span>
          )}
        </div>
        <div className="flex items-center gap-0.5 tracking-tight text-slate-400 text-sm font-serif">
          {blackCaptures.length > 0 ? (
            blackCaptures.map((p, idx) => (
              <span key={idx} className="opacity-80 hover:opacity-100" title={`Capturou ${p}`}>
                {PIECE_SYMBOLS[p] || p}
              </span>
            ))
          ) : (
            <span className="text-[10px] text-slate-500 italic">Nenhuma captura</span>
          )}
        </div>
      </div>
    </div>
  );
};
