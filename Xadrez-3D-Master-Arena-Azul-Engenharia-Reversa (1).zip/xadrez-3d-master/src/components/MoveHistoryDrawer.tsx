import React from 'react';
import { MoveRecord } from '../types/chess';
import { History, ChevronRight } from 'lucide-react';

interface MoveHistoryDrawerProps {
  history: MoveRecord[];
  isOpen: boolean;
  onToggle: () => void;
}

export const MoveHistoryDrawer: React.FC<MoveHistoryDrawerProps> = ({
  history,
  isOpen,
  onToggle
}) => {
  // Group moves into pairs (White & Black per round)
  const rounds: { roundNumber: number; white?: MoveRecord; black?: MoveRecord }[] = [];
  history.forEach((rec) => {
    let currentRound = rounds.find((r) => r.roundNumber === rec.moveNumber);
    if (!currentRound) {
      currentRound = { roundNumber: rec.moveNumber };
      rounds.push(currentRound);
    }
    if (rec.color === 'w') {
      currentRound.white = rec;
    } else {
      currentRound.black = rec;
    }
  });

  return (
    <div
      className={`fixed top-20 right-4 z-20 flex flex-col transition-all duration-300 ${
        isOpen ? 'w-64 max-h-[65vh]' : 'w-auto'
      }`}
    >
      {!isOpen ? (
        <button
          onClick={onToggle}
          className="flex items-center gap-2 bg-[#09152e]/90 hover:bg-[#0f234f] text-slate-200 border border-blue-900/60 px-3 py-2 rounded-xl backdrop-blur-md shadow-xl text-xs font-semibold cursor-pointer transition-all"
          title="Ver histórico de lances"
        >
          <History className="w-4 h-4 text-cyan-400" />
          <span>Lances ({history.length})</span>
        </button>
      ) : (
        <div className="bg-[#081226]/95 border border-blue-900/70 rounded-2xl shadow-2xl backdrop-blur-xl overflow-hidden flex flex-col">
          <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-blue-900/40 bg-[#0a1836]">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-bold text-slate-100">Histórico de Lances</span>
            </div>
            <button
              onClick={onToggle}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-blue-900/40 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="p-2.5 overflow-y-auto max-h-[50vh] flex flex-col gap-1 text-xs">
            {rounds.length === 0 ? (
              <div className="text-center py-6 text-slate-500 italic text-[11px]">
                Nenhum lance executado ainda.
              </div>
            ) : (
              rounds.map((rnd) => (
                <div
                  key={rnd.roundNumber}
                  className="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-blue-950/30 hover:bg-blue-900/30 border border-blue-900/20 font-mono text-[11px]"
                >
                  <span className="text-slate-500 font-semibold w-6">{rnd.roundNumber}.</span>
                  <span className="text-slate-100 font-bold flex-1 text-center">
                    {rnd.white ? rnd.white.san : '-'}
                  </span>
                  <span className="text-cyan-300 font-bold flex-1 text-center">
                    {rnd.black ? rnd.black.san : '-'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
