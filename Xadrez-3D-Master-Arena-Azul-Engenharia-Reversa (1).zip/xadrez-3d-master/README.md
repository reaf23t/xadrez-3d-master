# Xadrez 3D Master — Arena Azul

Versão reconstruída a partir do projeto enviado, mantendo o estilo **Navy & Sapphire**, o tabuleiro e as peças 3D, os três modos de jogo, os bots, o histórico, o chat, os efeitos sonoros e o multiplayer por salas.

## Requisitos

- Node.js 20.19+ (recomendado)
- npm
- Conexão com a internet na primeira instalação das dependências

## Executar o projeto completo

1. Extraia o ZIP para uma pasta.
2. Abra essa pasta no VS Code.
3. No terminal, execute:

   ```bash
   npm install
   npm run dev
   ```

4. Abra **http://localhost:3000** no navegador.

O servidor mantém as salas online em memória. Para jogar com alguém em outro computador, publique o projeto em um servidor acessível pela internet; `localhost` só é acessível no próprio computador. As salas são apagadas quando o servidor reinicia.

## Abrir a versão HTML local

Abra `Jogar-Local.html` com um navegador. Essa versão oferece o tabuleiro 3D para jogar contra um bot ou em modo local. Ela carrega Three.js, chess.js, Tailwind e alguns ícones por CDN, portanto precisa de internet para carregar essas bibliotecas. As duas trilhas de áudio estão embutidas no próprio HTML.

O modo online completo usa a aplicação principal executada com `npm run dev`, não o arquivo aberto via `file://`.

## Pastas importantes

- `src/App.tsx` — estado da partida, modos, movimentação, conexão online e interface principal.
- `src/components/Chess3DCanvas.tsx` — tabuleiro e peças 3D.
- `src/utils/aiEngine.ts` — avaliação e escolha de lances dos bots.
- `src/utils/soundEffects.ts` — efeitos sonoros.
- `server.ts` — API, salas online e eventos SSE. Os lances são validados pelo servidor com `chess.js`.
- `public/sounds/` — áudios usados pela aplicação React.

## Engenharia reversa realizada

A reconstrução foi baseada nos arquivos do projeto original enviado pelo usuário. A análise identificou a arquitetura React/Three.js, o motor `chess.js`, a IA Minimax com poda alfa-beta, os efeitos sonoros e a API SSE do multiplayer. Foram ajustados o fluxo de fim de partida no frontend, a reconstrução do histórico recebido pela sala e a validação autoritativa dos lances no servidor. O reset de sala também limpa o motivo de término anterior.

### Limites conhecidos

- A execução completa ainda deve ser testada com `npm install`, `npm run lint` e `npm run build` num ambiente com acesso ao registro npm.
- A identidade do jogador usa um identificador de sessão enviado pelo navegador; isso não equivale a autenticação forte. Para um serviço público, recomenda-se acrescentar tokens de sessão seguros, rate limiting e persistência de salas.
- As salas ficam em memória e são perdidas quando o servidor reinicia.
- Os níveis 4 e 5 usam profundidade de busca 3; os nomes dos níveis são perfis de dificuldade, não uma garantia de força de grande mestre.
- `Jogar-Local.html` usa bibliotecas por CDN, então não é totalmente offline. O modo online real só funciona pela aplicação com servidor.

## Observações

- A aplicação usa `chess.js` para validar as regras da partida.
- O multiplayer precisa de uma instância do servidor com acesso público para partidas entre pessoas em redes diferentes.
- Não é necessário fornecer uma chave Gemini para executar este jogo; o motor de bots incluído é local.
