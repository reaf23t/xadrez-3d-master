# Engenharia reversa — Xadrez 3D Master: Arena Azul

## Escopo
Análise estática do ZIP original fornecido na conversa e comparação com a versão reconstruída. A inspeção cobre frontend React, cena Three.js, regras de xadrez, IA, áudio, HTML standalone e API de salas.

## Arquitetura encontrada
- **React + TypeScript + Vite:** interface e estado da partida.
- **Three.js:** tabuleiro, pedestal, peças geométricas, luzes e câmera orbital.
- **chess.js:** legalidade dos lances, FEN, roque, en passant, promoção e detecção de fim de jogo.
- **Motor de IA próprio:** seleção aleatória no nível 1, avaliação material/posicional no nível 2 e Minimax com poda alfa-beta nos níveis 3–5.
- **Express + SSE:** API de salas e transmissão de atualizações em tempo real.
- **Web Audio e MP3:** efeitos de lance/captura/xeque e sons de vitória/derrota.

## Recursos observados no código
| Recurso | Estado pela inspeção estática |
|---|---|
| Tabuleiro e peças 3D | Presente no componente `Chess3DCanvas.tsx` |
| Câmera livre e presets | Presente no componente 3D e controles da interface |
| Destaques de jogadas | Presente na interface do tabuleiro |
| Regras oficiais e promoção | Motor `chess.js` e modal de promoção |
| Cinco perfis de bot | Presentes; níveis 4 e 5 compartilham profundidade de busca 3 |
| Dois jogadores locais | Presente no modo local da aplicação React |
| Salas online / SSE | API presente no servidor Express |
| Histórico, capturas e chat | Componentes presentes; histórico remoto foi sincronizado na reconstrução |
| Música e efeitos | MP3 e gerenciador de áudio presentes |
| HTML único | Incluído; importa bibliotecas externas por CDN e não é totalmente offline |

## Correções incluídas na reconstrução
1. O servidor passa a reconstruir a posição com `chess.js` e validar cada lance recebido, em vez de aceitar um FEN arbitrário enviado pelo cliente.
2. O servidor verifica se o identificador informado pertence a uma das cores da sala e se é a vez desse jogador antes de aceitar o lance.
3. Mensagens do chat têm validação de texto e limite de tamanho.
4. O frontend trata o fim de partida independentemente da mudança de FEN, importante para desistências.
5. O frontend reconstitui o histórico SAN recebido da sala e sincroniza o chat mesmo quando este é limpo.
6. O guard de fim de jogo evita repetir o modal e o áudio em atualizações SSE sucessivas.
7. O reinício de partida limpa também o motivo de término anterior.

## Riscos e limites que permanecem
- O identificador do jogador é gerado no navegador e enviado em requisições; sem autenticação/token de sessão assinado, um cliente malicioso pode tentar falsificá-lo. Não publique como serviço competitivo sem reforçar a autenticação.
- As salas ficam em memória; reiniciar o servidor apaga as partidas.
- Os códigos de sala são curtos; para produção, prefira IDs criptograficamente aleatórios e limites de tentativa.
- A versão HTML usa CDNs, logo precisa de internet para carregar dependências. O modo online real requer servidor.
- O motor de IA é recreativo e não equivale ao Stockfish; os níveis 4 e 5 usam profundidade 3.
- Não foi possível instalar as dependências neste ambiente porque o comando `npm install` excedeu o tempo limite. Portanto, não se afirma que o build completo foi executado. A sintaxe JavaScript extraída do HTML standalone passou em `node --check`.

## Testes recomendados após instalar dependências
```bash
npm install
npm run lint
npm run build
npm run dev
```
Depois, validar no navegador: promoção, roque, en passant, xeque-mate, empate, desistência, sincronização entre dois navegadores e reconexão a uma sala.
