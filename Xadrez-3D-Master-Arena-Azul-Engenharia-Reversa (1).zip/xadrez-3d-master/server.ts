import express, { Request, Response } from 'express';
import { Chess } from 'chess.js';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface MoveData {
  from: string;
  to: string;
  promotion?: string;
  san?: string;
  captured?: string;
  color?: string;
  piece?: string;
}

interface RoomChatMessage {
  id: string;
  sender: string;
  text: string;
  color?: string;
  avatar?: string;
  timestamp: number;
}

interface RoomState {
  code: string;
  fen: string;
  turn: 'w' | 'b';
  lastMove: { from: string; to: string } | null;
  history: MoveData[];
  whitePlayerId: string | null;
  blackPlayerId: string | null;
  whiteConnected: boolean;
  blackConnected: boolean;
  chat: RoomChatMessage[];
  isGameOver: boolean;
  winner: 'w' | 'b' | 'draw' | null;
  gameOverReason?: string;
  createdAt: number;
  updatedAt: number;
}

// In-memory rooms repository
const rooms = new Map<string, RoomState>();

// Active SSE connection clients per room code
const roomListeners = new Map<string, Set<Response>>();

function broadcastRoomUpdate(code: string) {
  const room = rooms.get(code);
  if (!room) return;

  const listeners = roomListeners.get(code);
  if (listeners && listeners.size > 0) {
    const payload = `data: ${JSON.stringify(room)}\n\n`;
    listeners.forEach((res) => {
      try {
        res.write(payload);
      } catch (err) {
        console.error('Error writing SSE payload:', err);
      }
    });
  }
}

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json({ limit: '100kb' }));

  // Default starting FEN
  const STARTING_FEN = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  // 1. Create a new room
  app.post('/api/rooms', (req: Request, res: Response) => {
    const playerId = typeof req.body?.playerId === 'string' ? req.body.playerId.trim() : '';
    if (!playerId || playerId.length > 100) {
      return res.status(400).json({ success: false, error: 'Identificador de jogador inválido' });
    }
    let code = `CHESS-${Math.floor(1000 + Math.random() * 9000)}`;
    while (rooms.has(code)) code = `CHESS-${Math.floor(1000 + Math.random() * 9000)}`;

    const newRoom: RoomState = {
      code,
      fen: STARTING_FEN,
      turn: 'w',
      lastMove: null,
      history: [],
      whitePlayerId: playerId,
      blackPlayerId: null,
      whiteConnected: true,
      blackConnected: false,
      chat: [
        {
          id: Date.now().toString(),
          sender: 'Sistema',
          text: `Sala ${code} criada! Aguardando o segundo jogador entrar...`,
          color: '#38bdf8',
          timestamp: Date.now()
        }
      ],
      isGameOver: false,
      winner: null,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    rooms.set(code, newRoom);
    res.json({ success: true, room: newRoom, assignedColor: 'w' });
  });

  // 2. Join an existing room (or reconnect with the same player ID)
  app.post('/api/rooms/:code/join', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const playerId = typeof req.body?.playerId === 'string' ? req.body.playerId.trim() : '';
    if (!playerId || playerId.length > 100) {
      return res.status(400).json({ success: false, error: 'Identificador de jogador inválido' });
    }

    const room = rooms.get(code);
    if (!room) {
      return res.status(404).json({ success: false, error: 'Sala não encontrada. Peça ao amigo para criar uma nova sala.' });
    }

    let assignedColor: 'w' | 'b';
    if (room.whitePlayerId === playerId) {
      assignedColor = 'w';
      room.whiteConnected = true;
    } else if (room.blackPlayerId === playerId) {
      assignedColor = 'b';
      room.blackConnected = true;
    } else if (!room.whitePlayerId) {
      room.whitePlayerId = playerId;
      room.whiteConnected = true;
      assignedColor = 'w';
    } else if (!room.blackPlayerId) {
      room.blackPlayerId = playerId;
      room.blackConnected = true;
      assignedColor = 'b';
    } else {
      return res.status(409).json({ success: false, error: 'Esta sala já está completa.' });
    }

    room.updatedAt = Date.now();
    room.chat.push({
      id: Date.now().toString(),
      sender: 'Sistema',
      text: `Jogador conectado como ${assignedColor === 'w' ? 'Brancas' : 'Pretas'}!`,
      color: '#34d399',
      timestamp: Date.now()
    });

    broadcastRoomUpdate(code);
    res.json({ success: true, room, assignedColor });
  });

  // 3. Get room state
  app.get('/api/rooms/:code', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const room = rooms.get(code);
    if (!room) {
      return res.status(404).json({ success: false, error: 'Sala não encontrada' });
    }
    res.json({ success: true, room });
  });

  // 4. SSE (Server-Sent Events) Stream for real-time room updates
  app.get('/api/rooms/:code/events', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const room = rooms.get(code);
    if (!room) return res.status(404).json({ success: false, error: 'Sala não encontrada' });

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive'
    });

    res.write('\n');

    if (!roomListeners.has(code)) {
      roomListeners.set(code, new Set());
    }
    roomListeners.get(code)!.add(res);

    // Send initial snapshot
    if (room) {
      res.write(`data: ${JSON.stringify(room)}\n\n`);
    }

    req.on('close', () => {
      const listeners = roomListeners.get(code);
      if (listeners) {
        listeners.delete(res);
        if (listeners.size === 0) {
          roomListeners.delete(code);
        }
      }
    });
  });

  // 5. Validate and post a legal move on the server (never trust client FEN)
  app.post('/api/rooms/:code/move', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const room = rooms.get(code);
    if (!room) return res.status(404).json({ success: false, error: 'Sala não encontrada' });
    if (room.isGameOver) return res.status(409).json({ success: false, error: 'A partida já terminou' });

    const { move, playerId } = req.body || {};
    if (!playerId || !move?.from || !move?.to) {
      return res.status(400).json({ success: false, error: 'Dados do lance incompletos' });
    }

    const playerColor: 'w' | 'b' | null =
      room.whitePlayerId === playerId ? 'w' : room.blackPlayerId === playerId ? 'b' : null;
    if (!playerColor) return res.status(403).json({ success: false, error: 'Jogador não pertence a esta sala' });
    if (playerColor !== room.turn) return res.status(403).json({ success: false, error: 'Não é a sua vez de jogar' });

    let game: Chess;
    try {
      game = new Chess(room.fen);
      const legalMove = game.move({
        from: move.from,
        to: move.to,
        ...(move.promotion ? { promotion: move.promotion } : {})
      });
      if (!legalMove) return res.status(400).json({ success: false, error: 'Lance ilegal' });

      room.fen = game.fen();
      room.lastMove = { from: legalMove.from, to: legalMove.to };
      room.turn = game.turn();
      room.history.push({
        from: legalMove.from,
        to: legalMove.to,
        promotion: legalMove.promotion,
        san: legalMove.san,
        captured: legalMove.captured,
        color: legalMove.color,
        piece: legalMove.piece
      });
      room.isGameOver = game.isGameOver();
      room.winner = game.isCheckmate()
        ? (game.turn() === 'w' ? 'b' : 'w')
        : game.isDraw() ? 'draw' : null;
      room.gameOverReason = game.isCheckmate() ? 'Xeque-mate' : game.isDraw() ? 'Empate' : undefined;
      room.updatedAt = Date.now();
    } catch (_error) {
      return res.status(400).json({ success: false, error: 'Lance inválido para a posição atual' });
    }

    broadcastRoomUpdate(code);
    res.json({ success: true, room });
  });

  // 6. Post chat message in room
  app.post('/api/rooms/:code/chat', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const room = rooms.get(code);
    if (!room) {
      return res.status(404).json({ success: false, error: 'Sala não encontrada' });
    }

    const { message, playerId } = req.body || {};
    if (!playerId || (room.whitePlayerId !== playerId && room.blackPlayerId !== playerId)) {
      return res.status(403).json({ success: false, error: 'Jogador não pertence a esta sala' });
    }
    if (!message || typeof message.text !== 'string' || !message.text.trim()) {
      return res.status(400).json({ success: false, error: 'Mensagem vazia' });
    }
    const text = message.text.trim();
    if (text.length > 500) return res.status(413).json({ success: false, error: 'A mensagem deve ter até 500 caracteres' });

    const chatMsg: RoomChatMessage = {
      id: Date.now().toString(),
      sender: room.whitePlayerId === playerId ? 'Jogador (Brancas)' : 'Jogador (Pretas)',
      text,
      color: room.whitePlayerId === playerId ? '#38bdf8' : '#a78bfa',
      avatar: message.avatar,
      timestamp: Date.now()
    };

    room.chat.push(chatMsg);
    room.updatedAt = Date.now();

    broadcastRoomUpdate(code);
    res.json({ success: true, message: chatMsg });
  });

  // 7. Reset game in room
  app.post('/api/rooms/:code/reset', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const room = rooms.get(code);
    if (!room) {
      return res.status(404).json({ success: false, error: 'Sala não encontrada' });
    }
    const { playerId } = req.body || {};
    if (!playerId || (room.whitePlayerId !== playerId && room.blackPlayerId !== playerId)) {
      return res.status(403).json({ success: false, error: 'Jogador não pertence a esta sala' });
    }

    room.fen = STARTING_FEN;
    room.turn = 'w';
    room.lastMove = null;
    room.history = [];
    room.isGameOver = false;
    room.winner = null;
    room.gameOverReason = undefined;
    room.updatedAt = Date.now();
    room.chat.push({
      id: Date.now().toString(),
      sender: 'Sistema',
      text: 'A partida online foi reiniciada! Vez das Brancas.',
      color: '#60a5fa',
      timestamp: Date.now()
    });

    broadcastRoomUpdate(code);
    res.json({ success: true, room });
  });

  // 8. Resign game in room
  app.post('/api/rooms/:code/resign', (req: Request, res: Response) => {
    const code = req.params.code.toUpperCase();
    const room = rooms.get(code);
    if (!room) {
      return res.status(404).json({ success: false, error: 'Sala não encontrada' });
    }

    const { playerId } = req.body || {};
    const resigningPlayerColor: 'w' | 'b' | null =
      room.whitePlayerId === playerId ? 'w' : room.blackPlayerId === playerId ? 'b' : null;
    if (!resigningPlayerColor) {
      return res.status(403).json({ success: false, error: 'Jogador não pertence a esta sala' });
    }
    if (room.isGameOver) return res.status(409).json({ success: false, error: 'A partida já terminou' });
    const winnerColor = resigningPlayerColor === 'w' ? 'b' : 'w';

    room.isGameOver = true;
    room.winner = winnerColor;
    room.gameOverReason = 'Desistência';
    room.updatedAt = Date.now();
    room.chat.push({
      id: Date.now().toString(),
      sender: 'Sistema',
      text: `O jogador de ${resigningPlayerColor === 'w' ? 'Brancas' : 'Pretas'} abandonou a partida. Vitória das ${winnerColor === 'w' ? 'Brancas' : 'Pretas'}!`,
      color: '#ef4444',
      timestamp: Date.now()
    });

    broadcastRoomUpdate(code);
    res.json({ success: true, room });
  });

  // Vite Integration
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`> Full-stack Chess 3D server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
