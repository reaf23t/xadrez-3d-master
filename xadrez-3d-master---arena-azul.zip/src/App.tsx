import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Chess, Square, Move } from 'chess.js';
import { Chess3DCanvas } from './components/Chess3DCanvas';
import { HUD } from './components/HUD';
import { CapturedTray } from './components/CapturedTray';
import { MoveHistoryDrawer } from './components/MoveHistoryDrawer';
import { ChatBox, ChatMessage } from './components/ChatBox';
import { WelcomeModal } from './components/Modals/WelcomeModal';
import { GameOverModal } from './components/Modals/GameOverModal';
import { PromotionModal } from './components/Modals/PromotionModal';
import { SoundSettingsModal } from './components/Modals/SoundSettingsModal';
import { GameMode, PieceColor, CapturedPieces, MoveRecord } from './types/chess';
import { BOT_PROFILES, computeBestMove, generateBotReaction } from './utils/aiEngine';
import { soundManager } from './utils/soundEffects';

export default function App() {
  // Chess engine instance
  const [chess] = useState(() => new Chess());
  const [, setTick] = useState(0); // Force re-render on chess state change

  // Game configuration & modes
  const [gameMode, setGameMode] = useState<GameMode>('BOT');
  const [botLevel, setBotLevel] = useState<number>(1);
  const [playerColor, setPlayerColor] = useState<PieceColor>('w');

  // UI state
  const [isWelcomeOpen, setIsWelcomeOpen] = useState<boolean>(true);
  const [isGameOverOpen, setIsGameOverOpen] = useState<boolean>(false);
  const [isSoundModalOpen, setIsSoundModalOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [cameraPreset, setCameraPreset] = useState<'white' | 'black' | 'top' | 'free'>('white');

  // Audio settings
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.8);
  const [isPlayingEndAudio, setIsPlayingEndAudio] = useState<boolean>(false);

  // Board interaction state
  const [selectedSquare, setSelectedSquare] = useState<Square | null>(null);
  const [possibleMoves, setPossibleMoves] = useState<Move[]>([]);
  const [lastMove, setLastMove] = useState<{ from: string; to: string } | null>(null);
  const [pendingPromotion, setPendingPromotion] = useState<{ from: Square; to: Square } | null>(null);

  // Game tracking
  const [moveHistory, setMoveHistory] = useState<MoveRecord[]>([]);
  const [captured, setCaptured] = useState<CapturedPieces>({ w: [], b: [] });
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);

  // Online multiplayer state
  const [onlineRoomCode, setOnlineRoomCode] = useState<string | null>(null);
  const broadcastChannelRef = useRef<BroadcastChannel | null>(null);

  // Bot thinking ref
  const isBotThinkingRef = useRef<boolean>(false);

  // Recalculate captured pieces by counting missing pieces from the initial 16 of each color
  const updateCapturedPieces = useCallback(() => {
    const fullSet: Record<string, number> = { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 };
    const currentCounts = {
      w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 } as Record<string, number>,
      b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 } as Record<string, number>
    };

    const board = chess.board();
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece) {
          currentCounts[piece.color][piece.type]++;
        }
      }
    }

    const capturedW: string[] = []; // White pieces captured by black
    const capturedB: string[] = []; // Black pieces captured by white

    for (const type of ['p', 'n', 'b', 'r', 'q']) {
      const lostW = fullSet[type] - currentCounts.w[type];
      for (let i = 0; i < lostW; i++) capturedW.push(type);

      const lostB = fullSet[type] - currentCounts.b[type];
      for (let i = 0; i < lostB; i++) capturedB.push(type);
    }

    setCaptured({ w: capturedW, b: capturedB });
  }, [chess]);

  // Execute a verified legal move
  const applyMove = useCallback(
    (from: Square, to: Square, promotionPiece?: 'q' | 'r' | 'b' | 'n'): boolean => {
      try {
        const move = chess.move({
          from,
          to,
          promotion: promotionPiece || 'q'
        });

        if (!move) return false;

        // Play sound effects
        if (move.captured) {
          soundManager.playCaptureSound();
        } else {
          soundManager.playMoveSound();
        }

        if (chess.inCheck()) {
          setTimeout(() => soundManager.playCheckSound(), 120);
        }

        // Update last move and board state
        setLastMove({ from: move.from, to: move.to });
        setTick((t) => t + 1);

        // Record history
        const newRecord: MoveRecord = {
          moveNumber: Math.ceil(chess.history().length / 2),
          color: move.color,
          san: move.san,
          from: move.from,
          to: move.to,
          captured: move.captured,
          piece: move.piece
        };
        setMoveHistory((prev) => [...prev, newRecord]);

        updateCapturedPieces();

        // Broadcast to online peer if in online mode
        if (gameMode === 'ONLINE' && onlineRoomCode && broadcastChannelRef.current) {
          broadcastChannelRef.current.postMessage({
            type: 'MOVE',
            roomCode: onlineRoomCode,
            from,
            to,
            promotion: promotionPiece || 'q',
            fen: chess.fen()
          });
        }

        // Check if game ended
        if (chess.isGameOver()) {
          handleGameOver();
        }

        return true;
      } catch (err) {
        console.warn('Move error:', err);
        return false;
      }
    },
    [chess, gameMode, onlineRoomCode, updateCapturedPieces]
  );

  // Handle Game Over logic & triggers the exact requested audio!
  const handleGameOver = useCallback(() => {
    setIsGameOverOpen(true);
    setIsPlayingEndAudio(true);

    if (chess.isCheckmate()) {
      const winner = chess.turn() === 'w' ? 'b' : 'w';
      const playerWon =
        gameMode === 'BOT'
          ? winner === playerColor
          : winner === 'w'; // In 2P local, white is perspective by default

      if (playerWon) {
        // Player WON -> Play UEFA Champions League anthem ("intro-uefa...")!
        soundManager.playVictorySound();
      } else {
        // Player LOST -> Play "Pegue seu banquinho e saia de mansinho..."!
        soundManager.playDefeatSound();
      }
    } else {
      // Draw / Stalemate
      soundManager.stopCelebrations();
    }
  }, [chess, gameMode, playerColor]);

  // Make Bot Move
  const triggerBotMove = useCallback(() => {
    if (chess.isGameOver() || isBotThinkingRef.current) return;
    const botColor: PieceColor = playerColor === 'w' ? 'b' : 'w';
    if (chess.turn() !== botColor) return;

    isBotThinkingRef.current = true;

    // Realistic human-like delay for bot contemplation
    setTimeout(() => {
      const bestMove = computeBestMove(chess, botLevel, botColor);
      if (bestMove) {
        applyMove(bestMove.from as Square, bestMove.to as Square, bestMove.promotion as 'q');

        // Bot contextual chat reaction
        const bot = BOT_PROFILES[botLevel];
        const reaction = generateBotReaction(botLevel, bestMove, chess, playerColor);
        setChatMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString(),
            sender: bot.name,
            text: reaction,
            avatar: bot.avatar,
            isBot: true
          }
        ]);
      }
      isBotThinkingRef.current = false;
    }, 550);
  }, [chess, botLevel, playerColor, applyMove]);

  // Watch for bot turn in BOT mode
  useEffect(() => {
    if (gameMode === 'BOT' && !isWelcomeOpen && !isGameOverOpen) {
      const botColor: PieceColor = playerColor === 'w' ? 'b' : 'w';
      if (chess.turn() === botColor) {
        triggerBotMove();
      }
    }
  }, [chess, gameMode, playerColor, isWelcomeOpen, isGameOverOpen, triggerBotMove]);

  // Handle square clicks on 3D board
  const handleSquareClick = (square: Square) => {
    if (isGameOverOpen || isBotThinkingRef.current) return;

    // If bot's turn in BOT mode, prevent human from clicking opponent pieces
    if (gameMode === 'BOT' && chess.turn() !== playerColor) return;

    const piece = chess.get(square);

    // If a piece is already selected and clicked square is one of legal targets:
    if (selectedSquare) {
      const isTargetValid = possibleMoves.some((m) => m.to === square);

      if (isTargetValid) {
        // Check for pawn promotion (White moving to rank 8 or Black to rank 1)
        const selectedPiece = chess.get(selectedSquare);
        if (
          selectedPiece &&
          selectedPiece.type === 'p' &&
          ((selectedPiece.color === 'w' && square[1] === '8') ||
            (selectedPiece.color === 'b' && square[1] === '1'))
        ) {
          // Open promotion dialog
          setPendingPromotion({ from: selectedSquare, to: square });
          setSelectedSquare(null);
          setPossibleMoves([]);
          return;
        }

        applyMove(selectedSquare, square);
        setSelectedSquare(null);
        setPossibleMoves([]);
        return;
      }
    }

    // Otherwise, select piece of the current turn
    if (piece && piece.color === chess.turn()) {
      setSelectedSquare(square);
      const moves = chess.moves({ square, verbose: true });
      setPossibleMoves(moves);
    } else {
      setSelectedSquare(null);
      setPossibleMoves([]);
    }
  };

  // Promotion choice execution
  const handleSelectPromotion = (promo: 'q' | 'r' | 'b' | 'n') => {
    if (pendingPromotion) {
      applyMove(pendingPromotion.from, pendingPromotion.to, promo);
      setPendingPromotion(null);
    }
  };

  // Player resigns (immediate defeat -> plays "Pegue seu banquinho"!)
  const handleResign = () => {
    if (chess.isGameOver()) return;
    setIsGameOverOpen(true);
    setIsPlayingEndAudio(true);
    // User surrendered -> Defeat track!
    soundManager.playDefeatSound();
  };

  // Reset Board / Rematch
  const handleResetGame = () => {
    chess.reset();
    setSelectedSquare(null);
    setPossibleMoves([]);
    setLastMove(null);
    setMoveHistory([]);
    setCaptured({ w: [], b: [] });
    setIsGameOverOpen(false);
    soundManager.stopCelebrations();
    setIsPlayingEndAudio(false);
    setTick((t) => t + 1);

    if (gameMode === 'ONLINE' && onlineRoomCode && broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({
        type: 'RESET',
        roomCode: onlineRoomCode
      });
    }

    setChatMessages((prev) => [
      ...prev,
      {
        id: Date.now().toString(),
        sender: 'Sistema',
        text: 'A partida foi reiniciada! Boa sorte a ambos.',
        color: '#60a5fa'
      }
    ]);
  };

  // Start vs Bot mode
  const handleStartBotGame = (level: number, color: PieceColor) => {
    setGameMode('BOT');
    setBotLevel(level);
    setPlayerColor(color);
    setCameraPreset(color === 'w' ? 'white' : 'black');
    setIsWelcomeOpen(false);
    handleResetGame();

    const bot = BOT_PROFILES[level];
    setChatMessages([
      {
        id: '1',
        sender: bot.name,
        text: bot.intro,
        avatar: bot.avatar,
        isBot: true
      }
    ]);
  };

  // Start 2P Local mode
  const handleStartLocalGame = () => {
    setGameMode('LOCAL');
    setPlayerColor('w');
    setCameraPreset('white');
    setIsWelcomeOpen(false);
    handleResetGame();

    setChatMessages([
      {
        id: '1',
        sender: 'Sistema',
        text: 'Modo 2 Jogadores Local iniciado. Ambos os jogadores compartilham a mesma tela!',
        color: '#34d399'
      }
    ]);
  };

  // Online Multiplayer Room Management
  const handleCreateOnlineRoom = () => {
    const code = `CHESS-${Math.floor(1000 + Math.random() * 9000)}`;
    setOnlineRoomCode(code);
    setupOnlineChannel(code);
    setGameMode('ONLINE');
    setPlayerColor('w');
    setCameraPreset('white');
    setIsWelcomeOpen(false);
    handleResetGame();

    setChatMessages([
      {
        id: '1',
        sender: 'Sistema',
        text: `Sala ${code} criada com sucesso! Compartilhe o código com seu amigo.`,
        color: '#38bdf8'
      }
    ]);
  };

  const handleJoinOnlineRoom = (code: string) => {
    setOnlineRoomCode(code);
    setupOnlineChannel(code);
    setGameMode('ONLINE');
    setPlayerColor('b');
    setCameraPreset('black');
    setIsWelcomeOpen(false);
    handleResetGame();

    setChatMessages([
      {
        id: '1',
        sender: 'Sistema',
        text: `Você entrou na sala ${code} como Pretas. Bom jogo!`,
        color: '#38bdf8'
      }
    ]);
  };

  const setupOnlineChannel = (code: string) => {
    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.close();
    }
    const channel = new BroadcastChannel(`chess-room-${code}`);
    channel.onmessage = (event) => {
      const data = event.data;
      if (data && data.roomCode === code) {
        if (data.type === 'MOVE') {
          try {
            chess.move({ from: data.from, to: data.to, promotion: data.promotion || 'q' });
            setLastMove({ from: data.from, to: data.to });
            updateCapturedPieces();
            setTick((t) => t + 1);
            soundManager.playMoveSound();
            if (chess.isGameOver()) handleGameOver();
          } catch (e) {
            console.error('Remote move sync error:', e);
          }
        } else if (data.type === 'RESET') {
          chess.reset();
          setSelectedSquare(null);
          setPossibleMoves([]);
          setLastMove(null);
          setMoveHistory([]);
          setCaptured({ w: [], b: [] });
          setTick((t) => t + 1);
        } else if (data.type === 'CHAT') {
          setChatMessages((prev) => [...prev, data.message]);
        }
      }
    };
    broadcastChannelRef.current = channel;
  };

  // Send Chat message
  const handleSendChat = (text: string) => {
    const newMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'Você',
      text,
      color: '#38bdf8'
    };
    setChatMessages((prev) => [...prev, newMsg]);

    // Broadcast chat to online peer
    if (gameMode === 'ONLINE' && onlineRoomCode && broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({
        type: 'CHAT',
        roomCode: onlineRoomCode,
        message: newMsg
      });
    }

    // Bot reply simulation
    if (gameMode === 'BOT') {
      setTimeout(() => {
        const bot = BOT_PROFILES[botLevel];
        const replies = [
          'Concentrado no jogo! Cada lance conta.',
          'Interessante estratégia... Estou calculando meus caminhos.',
          'Muito bom! Vamos ver como a posição evolui.',
          'Um grande duelo nesta arena azul!'
        ];
        const botReply: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: bot.name,
          text: replies[Math.floor(Math.random() * replies.length)],
          avatar: bot.avatar,
          isBot: true
        };
        setChatMessages((prev) => [...prev, botReply]);
      }, 1000);
    }
  };

  // Sound settings
  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    soundManager.setVolume(newVol);
  };

  const handleToggleMute = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    soundManager.setMuted(nextMute);
  };

  const handleToggleEndAudio = () => {
    if (isPlayingEndAudio) {
      soundManager.stopCelebrations();
      setIsPlayingEndAudio(false);
    } else {
      if (isGameOverOpen) {
        const winner = chess.turn() === 'w' ? 'b' : 'w';
        const playerWon = winner === playerColor;
        if (playerWon) {
          soundManager.playVictorySound();
        } else {
          soundManager.playDefeatSound();
        }
        setIsPlayingEndAudio(true);
      }
    }
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#030712] text-slate-100">
      {/* 3D Canvas Background */}
      <div className="absolute inset-0 z-0">
        <Chess3DCanvas
          chess={chess}
          playerColor={playerColor}
          onSquareClick={handleSquareClick}
          selectedSquare={selectedSquare}
          possibleMoves={possibleMoves}
          lastMove={lastMove}
          cameraPreset={cameraPreset}
        />
      </div>

      {/* Floating HUD Header */}
      <HUD
        gameMode={gameMode}
        botLevel={botLevel}
        currentTurn={chess.turn()}
        inCheck={chess.inCheck()}
        onOpenMenu={() => setIsWelcomeOpen(true)}
        onResetGame={handleResetGame}
        onResign={handleResign}
        onOpenAudioSettings={() => setIsSoundModalOpen(true)}
        cameraPreset={cameraPreset}
        onSetCameraPreset={setCameraPreset}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onlineRoomCode={onlineRoomCode}
      />

      {/* Captured Pieces Tray (Top Left) */}
      <div className="fixed top-20 left-4 z-20 pointer-events-auto">
        <CapturedTray captured={captured} playerColor={playerColor} />
      </div>

      {/* Move History Drawer (Top Right) */}
      <MoveHistoryDrawer
        history={moveHistory}
        isOpen={isHistoryOpen}
        onToggle={() => setIsHistoryOpen(!isHistoryOpen)}
      />

      {/* Chat Box (Bottom Left) */}
      <ChatBox
        messages={chatMessages}
        onSendMessage={handleSendChat}
        botProfile={gameMode === 'BOT' ? BOT_PROFILES[botLevel] : null}
        gameMode={gameMode}
      />

      {/* 3D Navigation Controls hint (Bottom Right) */}
      <div className="fixed bottom-4 right-4 z-10 hidden md:flex items-center gap-2 bg-[#081329]/80 border border-blue-900/50 backdrop-blur-md px-3.5 py-1.5 rounded-xl text-xs text-blue-200/70 shadow-lg pointer-events-none">
        <span className="w-2 h-2 rounded-full bg-cyan-400" />
        <span>Arraste para girar a câmera • Scroll para zoom</span>
      </div>

      {/* Welcome & Game Mode Chooser Modal */}
      <WelcomeModal
        isOpen={isWelcomeOpen}
        onStartBotGame={handleStartBotGame}
        onStartLocalGame={handleStartLocalGame}
        onCreateOnlineRoom={handleCreateOnlineRoom}
        onJoinOnlineRoom={handleJoinOnlineRoom}
        currentRoomCode={onlineRoomCode}
      />

      {/* Pawn Promotion Modal */}
      <PromotionModal
        isOpen={pendingPromotion !== null}
        color={chess.turn()}
        onSelect={handleSelectPromotion}
      />

      {/* Game Over Modal (Victory / Defeat Tracks) */}
      <GameOverModal
        isOpen={isGameOverOpen}
        isWin={
          chess.isCheckmate() &&
          ((chess.turn() === 'w' && playerColor === 'b') ||
            (chess.turn() === 'b' && playerColor === 'w'))
        }
        isDraw={chess.isDraw()}
        winnerColor={chess.isCheckmate() ? (chess.turn() === 'w' ? 'b' : 'w') : null}
        playerColor={playerColor}
        gameMode={gameMode}
        onRestart={handleResetGame}
        onMenu={() => {
          setIsGameOverOpen(false);
          setIsWelcomeOpen(true);
          soundManager.stopCelebrations();
        }}
        isPlayingAudio={isPlayingEndAudio}
        onToggleAudio={handleToggleEndAudio}
      />

      {/* Sound Settings & Audio Previews Modal */}
      <SoundSettingsModal
        isOpen={isSoundModalOpen}
        onClose={() => setIsSoundModalOpen(false)}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        volume={volume}
        onVolumeChange={handleVolumeChange}
      />
    </div>
  );
}
